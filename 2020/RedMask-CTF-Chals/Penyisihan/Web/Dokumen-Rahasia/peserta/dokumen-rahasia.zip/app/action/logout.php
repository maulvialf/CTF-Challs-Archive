<?php 
    $_SESSION['login'] = array(
        "auth" => false,
        "username" => null
    );

    header("Location: /");
