<?php

view('home');