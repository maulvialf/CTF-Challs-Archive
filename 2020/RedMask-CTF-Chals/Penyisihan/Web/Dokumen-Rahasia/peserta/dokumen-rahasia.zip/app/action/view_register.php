<?php

view('register');