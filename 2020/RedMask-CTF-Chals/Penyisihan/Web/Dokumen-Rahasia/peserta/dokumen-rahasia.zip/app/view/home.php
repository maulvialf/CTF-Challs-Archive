<h1>Dokumen Rahasia</h1>
<div class="row">
    <div class="col-12">
        <h4>Welcome, <?php echo safe($_SESSION['login']['username']); ?></h4>
    </div>
    <div class="col-12">
        <ul>
            <li><a href="/secret.php?name=dokumen_rahasia">Dokumen Rahasia #1</a></li>
        </ul>
    </div>
</div>