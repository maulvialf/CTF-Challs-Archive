import os
from aes import AES

FLAG = open('flag.txt', 'rb').read()

if __name__ == '__main__':

    aes = AES(os.urandom(16))
    iv = os.urandom(16)

    msg = input('Your msg >> ')

    print('Encrypted flag :', aes.encrypt_cbc(FLAG, iv).hex())
    print('Encrypted msg  :', aes.encrypt_cbc(msg.encode(), iv).hex())
