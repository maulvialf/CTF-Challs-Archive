#!/usr/bin/python3
from Crypto.Util.number import *
import random, os, base64
from libnum import grey_code
from valo import agents, maps, flag

LEN = 32
SECRET = os.urandom(LEN//2)

def next_prime(x):
    y = x | 1
    while not isPrime(y) or y == x:
        y += 2
    return y

def they_are_so_dead(x):
    a,b,c = x[0],x[1],x[2]
    for i in range((LEN << 11)+1):
        a,b,c = list(map(grey_code, [a,b,c]))
    return [a,b,c]

def invitation_code(x):
    rand = random.getrandbits(x * 8).to_bytes(x, 'little')
    return rand.hex()

class RANDOM:
    def __init__(self, seed, m):
        self.seed = seed
        self.m = next_prime(m)
        self.a = random.randint(1, m-1)
        self.c = random.randint(1, m-1)

    def next(self):
        self.seed = (self.seed * self.a + self.c) % self.m
        return self.seed

def encrypt(secret,mod):
    seed,mod = bytes_to_long(secret),int(mod[:LEN],16)
    prng = RANDOM(seed, mod)
    l_rand = they_are_so_dead([prng.next() for _ in range(3)])
    return base64.b64encode(b' >//< '.join([long_to_bytes(i) for i in l_rand])).decode()

def banner():
    print("\n" + "="*15 + " Hallo Pemain Satu " + "="*15)
    print("\n1) Get Invitation Code")
    print("2) Encrypted Secret")
    print("3) Guessing for Flag")
    print("4) I Don't Care\n")

while True:
    try:
        banner()
        choose = int(input("> "))
        if choose == 1:
            print("Hey mike, Let's play Valorand\n")
            print(f"Here's my Invitation Code: {invitation_code(LEN)} ")
        elif choose == 2:
            print(encrypt(SECRET, invitation_code(LEN)))
        elif choose == 3:
            awikwok = bytes_to_long(SECRET)
            idx = awikwok % len(agents)
            print("\nAs a friend, I'll test you to guess my favourite Agent & Map. Would ya?")
            ga = input("Your guess (agent): ")
            if (ga == agents[idx]):
                idx = (awikwok//(idx+1)) % len(maps)
                gm = input("Your guess (map): ")
                if (gm == maps[idx]):
                    print("No way, I bet you can't leaked my Secret haha")
                    gs = input("Secret (in hex): ").strip()
                    if (bytes.fromhex(gs) == SECRET):
                        print(f"Well, I think you deserve this {flag}")
                        exit()
                    else:
                        print("Ohhh damnn so close")
                        exit()
                else:
                    print("Wrong!")
                    exit()
            else:
                print("Wrong!, pffftt ur not my friend")
                exit()
        elif choose == 4:
            print("Understandable, Have a Great Day")
            exit()
        else:
            print("You choose violence huh?!\n")
    except:
        break
