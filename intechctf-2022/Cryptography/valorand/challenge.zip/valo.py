agents = ["Brimstone", "Phoenix", "Sage", "Sova", "Viper", "Cypher","Reyna","Killjoy", "Breach", "Omen", "Jett", "Raze","Skye", "Yoru", "Astra", "KAY/O", "Chamber", "Neon", "Fade"]

maps = ["HAVEN", "SPLIT", "ASCENT", "BIND", "ICEBOX", "BREEZE", "FRACTURE", "PEARL"]

flag = "put a flag here"
