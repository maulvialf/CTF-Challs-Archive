flag = "itf{REDACTED}"

def obfuscate(flag):
    diction = {0:1,1:2,2:3,3:4,4:5}
    flag = flag[::-1]
    temp = []
    temp.append(ord(flag[0]))
    for i in range(1, len(flag)):
        temp.append(ord(flag[i]) ^ temp[-1])
    res = []
    for i in temp:
        res.append(i + diction[i % 5])
    return res

print(obfuscate(flag))