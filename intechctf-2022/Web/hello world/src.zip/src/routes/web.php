<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::get("/template", function() {
    $template_name = str_replace("../", "", $_GET["template_name"]);
    if (isset($_GET["template_name"])){
        return file_get_contents($template_name);
    }
    return "no template specfied template";
});

Route::post("/template/post", function() {
    $template_name = str_replace("../", "", $_GET["template_name"]);
    if (isset($_POST["template_name"])){
        return file_get_contents($template_name);
    }
    return "no template specfied template";
});