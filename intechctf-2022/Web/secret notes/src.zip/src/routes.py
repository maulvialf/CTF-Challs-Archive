from functools import wraps
from flask import Blueprint, redirect, url_for, render_template, render_template_string, session, request, flash, jsonify

from models import Users, Secrets
from app import db
import config

secret_bp = Blueprint("routes", __name__)

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get("is_login"):
            flash("You need to login first!!", "error")
            return redirect(url_for('routes.login', next=request.url))
        return f(*args, **kwargs)
    return decorated_function

@secret_bp.route("/")
def index():
    return render_template("index.html", title="Secret Note Home")

@secret_bp.route("/register", methods=["GET", "POST"])
def register():
    
    if request.method == "POST":
        username = request.form.get("username", "guest")
        email = request.form.get("email", "guest@guest.com")
        password = request.form.get("password", "guest")

        if Users.check_email(email=email):
            flash("Email Already Registered!","error")
            return redirect(url_for("routes.register"))
        
        user = Users(username=username, email=email, password=password)
        db.session.add(user)
        db.session.commit()
        
        return redirect(url_for("routes.login"))

    return render_template("register.html", title="Secret Note - Register")

@secret_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "guest@guest.com")
        password = request.form.get("password", "guest")

        user = Users.query.filter_by(email=email, password=password).first()

        print(user)
        if user is None:
            flash("Email/Password Incorrect!!", "error")
            return redirect(url_for("routes.login"))


        session["user_id"] = user.id
        session["username"] = user.username
        session["email"] = user.email
        session["is_login"] = True


        return redirect(url_for("routes.secrets"))

    return render_template("login.html", title="Secret Note - Login")

@secret_bp.route("/logout", methods=["GET", "POST"])
@login_required
def logout():
    session.clear()
    return redirect(url_for("routes.login"))


@secret_bp.route("/secrets", methods=["GET", "POST"])
@login_required
def secrets():

    secrets_list = Secrets.query.filter_by(secret_owner=session.get("user_id")).all()
    content_list = []

    for secret in secrets_list:
        content = secret.content
        content_list.append(content)

    context = {"content" : content_list}

    return render_template("secrets.html", context=context)

# @secret_bp.route("/secret/<id>")
# def secret_by_id(id=None):
#
#     if id is None:
#         return redirect(url_for('routes.secrets'))
#
#     secret = Secrets.query.filter_by(id=id, secret_owner=session.get("user_id")).first()
#     if secret is None:
#         return redirect(url_for('routes.secrets'))
#
#
#     context = { "content" : secret.content}
#     return render_template("view_secret.html", title="Secret - {}".format(id), context=context)


@secret_bp.route("/secret/form", methods=["GET", "POST"])
@login_required
def secret_form():

    if request.method == "POST":
        content = request.form.get("content", "HELLO WORLD")

        for blacklist in config.BLACKLIST_CHAR:
            content = content.replace(blacklist, "*")

        content = render_template_string(content)
        secret = Secrets(secret_owner=session.get("user_id"), content=content)
        db.session.add(secret)
        db.session.commit()

        return redirect(url_for("routes.secrets"))

    return render_template("secret_form.html")

@secret_bp.context_processor
def context_processor():
    if not session.get("is_login"):
        return {"user_id" : "1337", "username" : "guest", "email" : "guest@guest.com", "is_login" : False}
    
    context = Users.query.get(session.get("user_id")).to_dict()
    context["is_login"] = True
    return context