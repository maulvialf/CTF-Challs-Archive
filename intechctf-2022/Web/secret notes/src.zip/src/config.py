BLACKLIST_CHAR = "_'.|\"" # Change this blacklist will make it easier
