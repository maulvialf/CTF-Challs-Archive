function getCookie(name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop().split(';').shift();
}
// initial
var num = 0+parseInt(getCookie('count'));

function cookieClick() {
    var numbers = document.getElementById("numbers");

    //upgrade level for printing
    var upgradeLevel = document.getElementById("upgradeLevel");

    //automatic Granny upgrade to 2x
    if (num >= 30) {
        num += 2;
        upgradeLevel.innerHTML = "Granny Level";
    }

    //automatic factory upgrade to 10x
    if (num >= 500) {
        num += 10;
        upgradeLevel.innerHTML = "Factory Level";
    }

    //automatic plant upgrade to 30x
    if (num >= 1000) {
        num += 30;
        upgradeLevel.innerHTML = "Plant Level";
    }

    //automatic super factory upgrade to 1000x
    if (num >= 100000) {
        num += 1000;
        upgradeLevel.innerHTML = "Super-Plant Level";
    }

    //automatic hacker upgrade to 1x
    if (num >= 100000000000000000000000000000) {
        num += 1;
        upgradeLevel.innerHTML = "Hacker Level";
    }
    
    else{
        num += 1;
    }
    
    //update value
    numbers.innerHTML = num;
    document.cookie="count="+num
}
