const express = require("express");
const cookieParser = require('cookie-parser');
const robot = require("./robot");
const clean = require('xss');

const app = express();
app.use(cookieParser());
app.use(express.urlencoded({ extended: false }));

const PORT = process.env.PORT;

const headers = (req, res, next) => {
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    return next();
}
app.use(headers);
app.use(express.static('public'))

const template = (name, count) => `
<html>
<head>
<link rel = "stylesheet" href = "/css/style.css"/>
<script type="text/javascript" src="/js/cookie.js"></script>
</head>
${name === '' ? '' : `<h1> Hello ${name}! </h1>`}
<div id = "cookie" onclick="cookieClick()">
    <img src="https://media.giphy.com/media/l0u0eiVkW4x0Y/200.gif" width="200px"/>
</div>

<p>Number of Cookies:</p>

<div id = "numbers">${count}</div>
<div id= "upgradeLevel"></div>

<form action="/report" method=POST style="text-align: center;">
  <label for="url">If you like this website, don't forget to give us feedback!</label>
  <br>
  <input type="text" id="site" name="url" style-"height:300"><br><br>
  <input type="submit" value="Submit" style="color:black">
</form>
</html>
`;


app.get('/', (req, res) => {
    if (req.cookies.name) {
        let final = {};
        if (typeof (req.cookies.name) === 'object') {
            final = req.cookies.name
        } else {
            final = {
                yourname: clean(req.cookies.name),
                clickamount: clean(req.cookies.count.toString())
            };
        }
        res.send(template(final.yourname, final.clickamount));
    } else {
        const initial = 'guest';
        res.cookie('name', initial, {
            httpOnly: true
        });
        res.cookie('count', 0, {
            httpOnly: false
        });
        res.redirect('/');
    }
});

app.post('/report', (req, res) => {
    const url = req.body.url;
    robot.visit(url);
    res.send('success!');
});

//not implemented yet in the template
app.get('/changename', (req, res) => {
    res.cookie('name', req.query.newname, {
        httpOnly: true
    });
    res.cookie('count', 0, {
        httpOnly: false
    });
    res.redirect('/');
});



app.listen(PORT, () => console.log((new Date()) + `: Web/adminsecret server listening on port ${PORT}`));
