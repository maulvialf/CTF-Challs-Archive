const vars = {
  TITLE: "My Super App!",
  SECRET: "here is my secret: https://www.youtube.com/watch?v=dQw4w9WgXcQ",
  FLAG: "REDACTEDFLAG",
};

export default vars;
