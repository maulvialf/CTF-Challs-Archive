import os

generate = lambda x: os.urandom(x).hex()
