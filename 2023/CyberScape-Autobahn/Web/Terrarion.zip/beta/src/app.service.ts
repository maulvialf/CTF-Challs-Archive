import { Inject, Injectable } from '@nestjs/common';
import { validateTarget } from './utils/validate-target.util';
import { executeShodan } from './scanner/shodan.scanner';
import { ClientProxy } from '@nestjs/microservices';

@Injectable()
export class AppService {
  constructor(@Inject('ALPHA') private client: ClientProxy) {}

  async createScan(data) {
    const targets = await validateTarget(data.targets);
    const scanResult = await this.getScanResult(targets);
    const eventMsg = {
      id: data.id,
      result: scanResult,
    };
    this.client.emit('alpha.scan.report', eventMsg);
  }

  async getScanResult(targets: object) {
    const result = {};
    for (const label in targets) {
      const response = await executeShodan(targets[label]);

      if (response) {
        result[label] = {
          ip: response.ip,
          ports: response.ports,
          vulns: response.vulns,
        };
      }
    }

    return result;
  }
}
