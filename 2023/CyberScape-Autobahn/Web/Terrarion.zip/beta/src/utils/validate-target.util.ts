import { fdns } from './fdns.util';

const isIP = (target) => target.match(/^[0-9\.]+$/);

const isDomain = (target) =>
  target.match(
    /^(([a-zA-Z0-9_][a-zA-Z0-9\-_]{0,61})?[a-zA-Z0-9_]\.)+(([a-zA-Z0-9][a-zA-Z0-9-]{0,61})?[a-zA-Z0-9])$/,
  );

export const validateTarget = async (targets) => {
  const scanTarget = {
    ips: {},
    domains: {},
  };

  for (const type in targets) {
    const children = targets[type];
    children.forEach((target) => {
      const currentTargets = scanTarget[type];
      if (type === 'ips' && !isIP(target.target)) return;
      if (type === 'domains' && !isDomain(target.target)) return;
      currentTargets[target.label] = target.target;
    });
  }

  const finalTarget = { ...scanTarget.ips };
  for (const label in scanTarget.domains) {
    const ip = await fdns(scanTarget.domains[label]);
    if (ip) {
      finalTarget[label] = ip;
    }
  }

  return finalTarget;
};
