import * as dns from 'dns';

export const fdns = async (target: string) => {
  return new Promise((resolve, reject) => {
    dns.lookup(target, (err, address, family) => {
      if (err) resolve('');
      resolve(address);
    });
  });
};
