import { promisify } from 'util';
import { exec } from 'child_process';

export const executeShodan = async (ip: string) => {
  const sanitize = ip.match(/^[0-9\.]+$/);
  if (!sanitize) {
    return false;
  }

  const cmd = `curl https://internetdb.shodan.io/${ip}`;
  const execute = promisify(exec);
  try {
    const { stdout } = await execute(cmd);
    return JSON.parse(stdout);
  } catch (e) {
    console.error(e);
  }
  return false;
};
