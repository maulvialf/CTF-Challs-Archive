import {
  Column,
  DataType,
  Model,
  PrimaryKey,
  Table,
} from 'sequelize-typescript';

@Table({ tableName: 'scan', timestamps: false })
export class ScanModel extends Model {
  @PrimaryKey
  @Column({ type: DataType.STRING })
  id: string;

  @Column({ type: DataType.STRING })
  scan_name: string;

  @Column({ type: DataType.STRING })
  scan_description: string;

  @Column({ type: DataType.STRING })
  origin_ip: string;

  @Column({ type: DataType.STRING })
  status: string;

  @Column({ type: DataType.JSON })
  targets: object;

  @Column({ type: DataType.JSON })
  result: object;
}
