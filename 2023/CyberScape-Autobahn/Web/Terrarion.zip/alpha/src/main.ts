import { NestFactory } from '@nestjs/core';
import { Transport } from '@nestjs/microservices';
import { NestExpressApplication } from '@nestjs/platform-express';
import { join } from 'path';
import { AppModule } from './app.module';
import { DefaultIfEmptyInterceptor } from './interceptor/default-if-empty.interceptor';

async function bootstrap() {
  const app = await NestFactory.create<NestExpressApplication>(AppModule);

  app.connectMicroservice({
    transport: Transport.REDIS,
    options: {
      host: 'terrarion-redis',
      port: 6379,
    },
  });

  app.useGlobalInterceptors(new DefaultIfEmptyInterceptor());

  app.useStaticAssets(join(__dirname, '..', 'public'));
  app.setBaseViewsDir(join(__dirname, '..', 'views'));
  app.setViewEngine('hbs');

  await app.startAllMicroservices();
  await app.listen(3000);
}
bootstrap();
