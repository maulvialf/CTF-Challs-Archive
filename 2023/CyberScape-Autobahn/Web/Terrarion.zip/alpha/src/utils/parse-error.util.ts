import { ValidationError } from 'class-validator';

export const parseError = (error: ValidationError) => {
  if (error.children.length) {
    return parseError(error.children[0]);
  }
  return error.constraints;
};
