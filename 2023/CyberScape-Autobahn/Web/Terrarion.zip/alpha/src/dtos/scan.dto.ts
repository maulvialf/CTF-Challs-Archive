import { Type } from 'class-transformer';
import { IsNotEmpty, IsString, ValidateNested } from 'class-validator';
import { TargetsDTO } from './targets.dto';

export class CreateScanDTO {
  @IsString()
  @IsNotEmpty()
  scan_name: string;

  @IsString()
  scan_description: string;

  @IsNotEmpty()
  @ValidateNested()
  @Type(() => TargetsDTO)
  targets: TargetsDTO;
}
