import { Type } from 'class-transformer';
import {
  IsAlphanumeric,
  IsArray,
  IsIP,
  IsNotEmpty,
  IsOptional,
  IsString,
  Matches,
  ValidateNested,
} from 'class-validator';

class IpDTO {
  @IsString()
  @IsAlphanumeric()
  @IsNotEmpty()
  label: string;

  @IsString()
  @IsIP()
  target: string;
}

class DomainDTO {
  @IsString()
  @IsAlphanumeric()
  @IsNotEmpty()
  label: string;

  @IsString()
  @IsNotEmpty()
  @Matches(
    /^(([a-zA-Z0-9_][a-zA-Z0-9\-_]{0,61})?[a-zA-Z0-9_]\.)+(([a-zA-Z0-9][a-zA-Z0-9-]{0,61})?[a-zA-Z0-9])$/,
    { message: 'Target should be domain' },
  )
  target: string;
}

export class TargetsDTO {
  @IsArray()
  @IsOptional()
  @ValidateNested({ each: true })
  @Type(() => IpDTO)
  ips: IpDTO[];

  @IsArray()
  @IsOptional()
  @ValidateNested({ each: true })
  @Type(() => DomainDTO)
  domains: DomainDTO[];
}
