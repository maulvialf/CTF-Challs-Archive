import {
  Inject,
  Injectable,
  InternalServerErrorException,
} from '@nestjs/common';
import { ClientProxy } from '@nestjs/microservices';
import { CreateScanDTO } from './dtos/scan.dto';
import { InjectModel } from '@nestjs/sequelize';
import { ScanModel } from './model/scan.model';
import { randomUUID } from 'crypto';
import { readFileSync } from 'fs';

@Injectable()
export class AppService {
  constructor(
    @Inject('BETA') private client: ClientProxy,
    @InjectModel(ScanModel) private scanModel: typeof ScanModel,
  ) {}

  getScanList(ip) {
    return this.findAllScan(ip);
  }

  async createScan(data: CreateScanDTO, ip) {
    const created = await this.newScan({
      id: randomUUID(),
      ...data,
      origin_ip: ip,
      status: 'pending',
    });
    if (!created) {
      throw new InternalServerErrorException('Database error');
    }
    const eventMsg = {
      id: created.id,
      targets: data.targets,
    };
    return this.client.emit<object>('beta.scan', eventMsg);
  }

  async receiveScanResult(data) {
    const updatedData = {
      result: data.result,
      status: 'finished'
    }
    return this.updateScan(data.id, updatedData);
  }

  async getFlag(data){
    const flag = readFileSync('./flag.txt').toString();
    const updatedData = {
      result: { flag }
    }
    return this.updateScan(data.id, updatedData);
  }

  async findAllScan(ip) {
    return this.scanModel.findAll({
      where: {
        origin_ip: ip,
      },
    });
  }

  async newScan(data) {
    return this.scanModel.create(data);
  }

  async updateScan(id, data) {
    return this.scanModel.update(
      data,
      {
        where: {
          id,
        },
      },
    );
  }
}
