import { Module } from '@nestjs/common';
import { ClientsModule, Transport } from '@nestjs/microservices';
import { SequelizeModule } from '@nestjs/sequelize';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ScanModel } from './model/scan.model';

@Module({
  imports: [
    ClientsModule.register([
      {
        name: 'BETA',
        transport: Transport.REDIS,
        options: {
          host: 'terrarion-redis',
          port: 6379,
        },
      },
    ]),
    SequelizeModule.forRoot({
      dialect: 'postgres',
      host: 'terrarion-psql',
      port: 5432,
      username: 'postgres',
      password: 'postgres',
      database: 'postgres',
      models: [ScanModel],
    }),
    SequelizeModule.forFeature([ScanModel]),
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
