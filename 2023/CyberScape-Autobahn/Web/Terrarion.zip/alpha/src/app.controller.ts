import { BadRequestException, Body, Ip, Render } from '@nestjs/common';
import { Controller, Get, Post } from '@nestjs/common';
import { EventPattern } from '@nestjs/microservices';
import { plainToInstance } from 'class-transformer';
import { validate } from 'class-validator';
import { AppService } from './app.service';
import { CreateScanDTO } from './dtos/scan.dto';
import { parseError } from './utils/parse-error.util';

@Controller('')
export class AppController {
  constructor(private readonly appService: AppService) {}

  @Get()
  @Render('index')
  root(@Ip() ip){
    return { ip }
  }

  @Get('new')
  @Render('new')
  newScanPage(){
    return {}
  }

  @Get('scan')
  @Render('scan')
  scanListPage(){
    return {}
  }

  @Get('/api/scan')
  getScanList(@Ip() ip) {
    return this.appService.getScanList(ip);
  }

  @Post('/api/scan')
  async createScan(@Body() data: CreateScanDTO, @Ip() ip) {
    const dataObject = plainToInstance(CreateScanDTO, data);
    const isValid = await validate(dataObject);
    if (isValid.length) {
      throw new BadRequestException(parseError(isValid[0]));
    }
    return this.appService.createScan(data, ip);
  }

  @EventPattern('alpha.scan.report')
  receiveScanReport(data) {
    return this.appService.receiveScanResult(data);
  }

  @EventPattern('alpha.flag')
  receiveFlag(data){
    return this.appService.getFlag(data);
  }
}
