"""Parsers and serializers for /auth API endpoints."""
from flask_restx.reqparse import RequestParser
import werkzeug
from flask_restx import Model
from flask_restx.fields import String, Integer


user_data_parser = RequestParser(bundle_errors=True)
user_data_parser.add_argument(
    name="first_name", type=str, location="json", required=True, nullable=False
)
user_data_parser.add_argument(
    name="last_name", type=str, location="json", required=True, nullable=False
)
user_data_parser.add_argument(
    name="address", type=str, location="json", required=True, nullable=False
)
user_data_parser.add_argument(
    name="phone", type=str, location="json", required=True, nullable=False
)
user_data_parser.add_argument(
    name="short_intro", type=str, location="json", required=True, nullable=False
)
user_data_parser.add_argument(
    name="cv_file", type=str, location="json", required=True, nullable=False
)

file_reqparser = RequestParser(bundle_errors=True)
file_reqparser.add_argument('file', type=werkzeug.datastructures.FileStorage, location='files')

user_data_model = Model(
    "UserData",
    {
        "first_name": String,
        "last_name": String,
        "address": String,
        "phone": String,
    },
)