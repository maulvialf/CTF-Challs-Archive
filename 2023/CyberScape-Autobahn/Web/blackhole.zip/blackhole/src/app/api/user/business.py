"""Business logic for /auth API endpoints."""
from http import HTTPStatus
import os

from flask import current_app, jsonify, send_file
from werkzeug.utils import secure_filename

from app import db
from app.api.auth.decorators import token_required
from app.models.user_data import UserData
from app.util.converter import json2object

@token_required
def process_upload_cv(cv_file):
    filename = secure_filename(cv_file.filename)
    try:
        extension = filename.split(".")[-1]
        if extension not in ["pdf","docx","txt","xlsx"]:
            raise Exception("Invalid file")

        upload_path = os.path.join(os.getcwd(), current_app.config.get("UPLOAD_PATH"), filename)
        cv_file.save(upload_path)

        response = jsonify(
            status="success",
            message="successfully uploaded",
            filename=filename
        )
        response.status_code = HTTPStatus.CREATED
        response.headers["Cache-Control"] = "no-store"
        response.headers["Pragma"] = "no-cache"
        return response

    except Exception as e:
        response = jsonify(
            status="fail",
            message="Something when wrong :(",
        )
        response.status_code = HTTPStatus.BAD_REQUEST
        response.headers["Cache-Control"] = "no-store"
        response.headers["Pragma"] = "no-cache"
        return response

@token_required
def get_user_data():
    user_id = get_user_data.public_id
    data = UserData.find_by_user_id(user_id)
    return data

@token_required
def update_user_data(json_data):
    try:
        user_id = update_user_data.public_id
        json_data['user_id'] = user_id
        UserData.delete_if_exist(user_id)    
        user_data = UserData()
        json_data["cv_file"] = secure_filename(json_data["cv_file"])
        csv_file_path = os.path.join(os.getcwd(), current_app.config.get("UPLOAD_PATH"), json_data["cv_file"])
        
        if not os.path.exists(csv_file_path):
            raise Exception("File not found")

        json2object(json_data, user_data)
        db.session.add(user_data)
        db.session.commit()
        response = jsonify(
                status="success",
                message="Data successfully updated",
            )
        response.status_code = HTTPStatus.CREATED
        response.headers["Cache-Control"] = "no-store"
        response.headers["Pragma"] = "no-cache"
        return response
    except:
        response = jsonify(
            status="fail",
            message="File Not Found",
        )
        response.status_code = HTTPStatus.NOT_FOUND
        response.headers["Cache-Control"] = "no-store"
        response.headers["Pragma"] = "no-cache"
        return response

@token_required
def process_download_cv():
    user_id = process_download_cv.public_id    
    cv_file_path = UserData.get_cv_file(user_id)
    if not cv_file_path:
        response = jsonify(
            status="fail",
            message="File Not Found",
        )
        response.status_code = HTTPStatus.NOT_FOUND
        response.headers["Cache-Control"] = "no-store"
        response.headers["Pragma"] = "no-cache"
        return response
    
    return send_file(cv_file_path)