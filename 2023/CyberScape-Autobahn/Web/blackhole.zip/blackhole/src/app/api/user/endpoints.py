from http import HTTPStatus
from flask import request
from flask_restx import Namespace, Resource
from .dto import user_data_parser, file_reqparser, user_data_model
from .business import (
    update_user_data,
    get_user_data,
    process_upload_cv,
    process_download_cv
)

user_ns = Namespace(name="user", validate=True)

@user_ns.route("/upload/cv", endpoint="upload_cv")
class UploadCV(Resource):
    """Handles HTTP requests to URL: /api/v1/user/upload/cv."""

    @user_ns.doc(security="Bearer")
    @user_ns.response(int(HTTPStatus.BAD_REQUEST), "Validation error.")
    @user_ns.response(int(HTTPStatus.INTERNAL_SERVER_ERROR), "Internal server error.")
    def post(self):
        cv_file = file_reqparser.parse_args()
        return process_upload_cv(cv_file['file'])

@user_ns.route("/download/cv", endpoint="list_exam")
class DownloadCV(Resource):
    """Handles HTTP requests to URL: /api/v1/user/download/cv."""

    @user_ns.response(int(HTTPStatus.BAD_REQUEST), "Validation error.")
    @user_ns.response(int(HTTPStatus.UNAUTHORIZED), "Token is invalid or expired.")
    def get(self):
        return process_download_cv()

@user_ns.route("/data", endpoint="get_user_data")
class GetUserData(Resource):
    """Handles HTTP requests to URL: /api/v1/user/data"""

    @user_ns.response(int(HTTPStatus.BAD_REQUEST), "Validation error.")
    @user_ns.response(int(HTTPStatus.UNAUTHORIZED), "Token is invalid or expired.")
    @user_ns.marshal_with(user_data_model)
    def get(self):
        return get_user_data()

@user_ns.route("/data", endpoint="update_user_data")
class UpdateUserData(Resource):
    """Handles HTTP requests to URL: /api/v1/user/data."""

    @user_ns.response(int(HTTPStatus.BAD_REQUEST), "Validation error.")
    @user_ns.response(int(HTTPStatus.UNAUTHORIZED), "Token is invalid or expired.")
    def post(self):
        user_data_parser.parse_args()
        json_data = request.json
        return update_user_data(json_data)