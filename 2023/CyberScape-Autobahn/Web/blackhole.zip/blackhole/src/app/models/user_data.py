"""Class definition for User model."""
from os import getcwd, path
from flask import current_app

from app import db

class UserData(db.Model):
    __tablename__ = "user_data"

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    first_name = db.Column(db.String(255), nullable=False)
    last_name = db.Column(db.String(100), nullable=False)
    address = db.Column(db.String(255), nullable=False)
    phone = db.Column(db.String(255), nullable=False)
    short_intro = db.Column(db.String(255), nullable=False)
    cv_file = db.Column(db.String(255), nullable=False)
    
    user_id = db.Column(db.String(36), unique=True)
    
    def __repr__(self):
        return (
            f"<UserData first_name={self.first_name}, last_name={self.last_name}>"
        )

    @classmethod
    def get_cv_file(cls, user_id):
        data = cls.query.filter_by(user_id=user_id).first()
        if data:
            file_path = path.join(getcwd(), current_app.config["UPLOAD_PATH"], data.cv_file)
            print(file_path)
            return file_path
        return None
    
    @classmethod
    def find_by_user_id(cls, user_id):
        return cls.query.filter_by(user_id=user_id).first()

    @classmethod
    def delete_if_exist(cls, user_id):
        return cls.query.filter_by(user_id=user_id).delete()
