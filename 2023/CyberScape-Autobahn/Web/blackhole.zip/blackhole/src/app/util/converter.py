def json2object(json_src,obj_target):
    for key, value in json_src.items():
        if hasattr(obj_target, key) and type(value) == dict:
            json2object(value, getattr(obj_target, key))
        elif hasattr(obj_target, '__getitem__'):
            if obj_target.get(key) and type(value) == dict:
                json2object(value, obj_target.get(key))
            else:
                obj_target[key] = value
        else:
            setattr(obj_target, key, value)