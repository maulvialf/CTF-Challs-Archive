#!/usr/bin/env python3
from Crypto.Util.number import *
from Crypto.Cipher import PKCS1_v1_5
from Crypto.PublicKey import RSA
from base64 import b64encode
from functools import reduce

FLAG = open("flag.txt", "rb").read()

mul = lambda arr: reduce(lambda x, y: x * y, arr)

def cbyyneq(nbit, psmth, k):
    pbit = nbit // k
    primes = [0]
    n = 0

    while True:
        arr = [getPrime(psmth) for _ in range(pbit // psmth)]
        if len(arr) != len(set(arr)):
            continue

        p = mul(arr)
        if p.bit_length() < pbit - 1:
            p = p * getPrime(pbit - 1 - p.bit_length())

        p = 2 * p + 1
        if isPrime(p) and p.bit_length() == pbit and p > min(primes):
            n = mul(primes := sorted(primes + [p], key=lambda x: -x)[:k])
            if n.bit_length() == nbit:
                break

    return n

def write(data, filename):
    f = open(filename, "wb")
    f.write(data)
    f.close()

def main():
    key = RSA.construct((cbyyneq(1536, 28, 3), 65537))
    out = PKCS1_v1_5.new(key).encrypt(FLAG)
    write(key.export_key(), "key.pub")
    write(b64encode(out), "out.txt")

if __name__ == "__main__":
    main()
