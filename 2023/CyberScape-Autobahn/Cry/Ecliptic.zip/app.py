import json
from fastapi import FastAPI, HTTPException, Header, Depends
from typing import Union
from pydantic import BaseModel

from auth import encrypt_and_sign, decrypt_and_verify

app = FastAPI()


class Credential(BaseModel):
    username: str


async def verify_token(authorization: Union[str, None] = Header(default=None)):
    try:
        bearer, token = authorization.split(" ")
        if bearer == 'Bearer':
            data = decrypt_and_verify(token)
            return data

        raise HTTPException(401)
    except Exception:
        raise HTTPException(401)


@app.get("/")
def root():
    return {'message': 'Welcome to the Ecliptic of the Milky Way'}


@app.post("/auth")
def get_token(credential: Credential):
    data = json.dumps({
        'username': credential.username,
        'role': 'user'
    })

    token = encrypt_and_sign(data)
    return {'access_token': token}


@app.get("/auth")
def read_token(data=Depends(verify_token)):

    return json.loads(data)
