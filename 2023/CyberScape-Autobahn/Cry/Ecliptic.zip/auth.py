from jwkest.ecc import NISTEllipticCurve
from jwkest.jwk import ECKey
from jwkest.jwe import JWE, factory

FLAG = open('flag.txt', 'rb').read()

curve = NISTEllipticCurve.by_name('P-256')
priv = int.from_bytes(FLAG, 'big')
pub = curve.public_key_for(priv)

assert priv.bit_length() == 167

keys = ECKey(crv=curve.name(), x=pub[0], y=pub[1], d=priv)

def encrypt_and_sign(msg: str):

    jwe = JWE(msg, alg="ECDH-ES", enc="A128CBC-HS256")
    return jwe.encrypt([keys])


def decrypt_and_verify(token: str):

    jwe = factory(token)
    return jwe.decrypt(token, [keys])