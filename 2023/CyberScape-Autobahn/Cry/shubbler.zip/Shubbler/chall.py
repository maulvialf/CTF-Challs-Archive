#!/usr/bin/env python3
import random

FLAG = open("flag.txt", "rb").read()

def shubble(pt, key1, key2, key3):
    m = int.from_bytes(pt, "big")
    ct = ""
    while m:
        ct += chr((m % key1) ^ key2)
        m //= key1
    ct = list(ct)
    random.seed(key3)
    random.shuffle(ct)
    return "".join(ct)

key1 = random.randint(0x20, 0xEF)
key2 = random.randint(0x1F600, 0x1F6FF)
key3 = random.randint(0x20, 0xFF)
print(shubble(FLAG, key1, key2, key3))
