public class BlazinglyFastBank {
    public static long[] me = new long[10];
    public static long[] notMe = new long[10];
    public static long[] notMeEither = new long[10];
}

