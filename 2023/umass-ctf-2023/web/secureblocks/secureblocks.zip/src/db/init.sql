CREATE DATABASE IF NOT EXISTS secureblocks;
USE secureblocks;

CREATE TABLE users 
(username VARCHAR(255), password VARCHAR(255), diamonds INT(64));

INSERT INTO users (username,password,diamonds) 
VALUES 
('admin','test',9999999);