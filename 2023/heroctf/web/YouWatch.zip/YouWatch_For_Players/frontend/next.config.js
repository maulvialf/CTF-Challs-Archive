/** @type {import('next').NextConfig} */
const nextConfig = {
    // TODO
}

module.exports = nextConfig;