#!/bin/bash
node /app/bot.js &
node /app/server.js