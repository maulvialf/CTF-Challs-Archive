package common

import (
	"crypto/rand"
	"encoding/hex"
)

func GenerateHexChar(length int) string {
	randomBytes := make([]byte, length/2) // Divide by 2 since each byte is represented by 2 hex digits
	_, err := rand.Read(randomBytes)
	if err != nil {
		return err.Error()
	}

	hexString := hex.EncodeToString(randomBytes)
	return hexString
}
