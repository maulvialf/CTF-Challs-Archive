package session

import (
	"errors"
	"os"
	"strings"
	"time"

	jwt "github.com/dgrijalva/jwt-go"
	"github.com/gofiber/fiber/v2"
)

var secretKey []byte
var validSession = make(map[int]bool)

const tokenExpired = 12

type Claims struct {
	ID       int
	Username string
	IsAdmin  bool
	jwt.StandardClaims
}

func init() {
	secretKeyStr := os.Getenv("SECRET_KEY")
	secretKey = []byte(secretKeyStr)
}

func getToken(c *fiber.Ctx) (string, error) {
	var tokenString string
	authorization := c.Get("Authorization")

	if strings.HasPrefix(authorization, "Bearer ") {
		tokenString = strings.TrimPrefix(authorization, "Bearer ")
	} else if c.Cookies("token") != "" {
		tokenString = c.Cookies("token")
	}

	if tokenString == "" {
		return tokenString, errors.New("not logged in")
	}
	return tokenString, nil
}

func AuthorizationCheck(c *fiber.Ctx) error {
	tokenString, err := getToken(c)

	if err != nil {
		return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{"success": false, "message": "You are not logged in"})
	}

	claims, respCode := getClaims(tokenString)
	if respCode != 200 {
		return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{"success": false, "message": "Invalid Token"})
	}

	c.Locals("user", claims)

	return c.Next()
}

func AdminAuthorizationCheck(c *fiber.Ctx) error {
	tokenString, err := getToken(c)

	if err != nil {
		return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{"success": false, "message": "You are not logged in"})
	}

	claims, respCode := getClaims(tokenString)
	if respCode != 200 {
		return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{"success": false, "message": "Invalid Token"})
	}

	if !claims.IsAdmin {
		return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{"success": false, "message": "You are not Admin"})
	}

	c.Locals("user", claims)

	return c.Next()
}

func GenerateToken(id int, username string, isAdmin bool) (string, time.Time, error) {
	expirationTime := time.Now().Add(tokenExpired * time.Hour)
	claims := &Claims{
		Username: username,
		ID:       id,
		IsAdmin:  isAdmin,
		StandardClaims: jwt.StandardClaims{
			ExpiresAt: expirationTime.Unix(),
		},
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	tokenString, err := token.SignedString(secretKey)
	if err == nil {
		validSession[id] = true
	}
	return tokenString, expirationTime, err
}

func getClaims(token string) (*Claims, int) {
	claims := &Claims{}
	if token == "" {
		return claims, 401
	}

	tkn, err := jwt.ParseWithClaims(token, claims, func(token *jwt.Token) (interface{}, error) {
		return secretKey, nil
	})

	if err != nil {
		if err == jwt.ErrSignatureInvalid {
			return claims, 400
		}
		return claims, 401
	}

	if tkn.Valid {
		return claims, 200
	}
	return claims, 401
}

func RemoveToken(id int) {
	delete(validSession, id)
}
