pub const STORAGE_PATH: &str = "/tmp/io-storage/";
pub const TOKEN_PATH: &str = "/tmp/io-storage/admin/";
pub const OK: &str = "OK";
pub const ERROR : &str = "ERROR";
pub const INVALID_CHARS: &str = " !#$%&()*+,.:;<=>?@[\\]^`{|}";