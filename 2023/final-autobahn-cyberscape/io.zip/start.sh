# run sshd
/usr/sbin/sshd -D &
# run the command
./target/release/io