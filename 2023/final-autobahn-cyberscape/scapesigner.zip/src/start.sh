#!/bin/bash

/usr/sbin/sshd -D &
./main.py
