export { Promo } from "./Promo";
