#!/bin/bash

/chall/scripts/decompile_binja.py
