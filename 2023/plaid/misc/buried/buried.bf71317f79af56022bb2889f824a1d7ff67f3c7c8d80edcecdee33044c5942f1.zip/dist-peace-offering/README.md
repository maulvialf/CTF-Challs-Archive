It is NOT recommended that you try to run the full challenge locally, but a
docker-compose.yml file is provided so you can see how it is running on remote.

The binja image will fail to build/run without a headless license, which you
are NOT expected to have. (You can modify it to work with a commerical
license, but that should not be necessary or useful for this challenge.)

The handout is identical for the two parts. As shown in the docker-compose
file, the only difference is the LEVEL envrionment variable.
