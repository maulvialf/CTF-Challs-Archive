flag_s = "p4{fakeflag}"
