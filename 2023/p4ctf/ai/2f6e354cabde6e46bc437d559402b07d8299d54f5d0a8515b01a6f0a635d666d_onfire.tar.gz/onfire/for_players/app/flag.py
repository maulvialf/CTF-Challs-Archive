flag_list = [(ord(x)) for x in "p4{fakeflag}"]
