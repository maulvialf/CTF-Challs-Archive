package main

import (
	"bytes"
	"context"
	"log"
	"net"
	"os"
	"os/exec"
	"syscall"
	"time"
)

func runIPC() error {
	socketFile := "/tmp/gwin_sock"
	os.Remove(socketFile)

	listener, err := net.Listen("unix", socketFile)
	if err != nil {
		panic(err)
	}
	defer listener.Close()

	for i := 0; i < 3; i++ {
		conn, err := listener.Accept()
		if err != nil {
			continue
		}
		go handleConnection(conn)
	}

	return nil
}

func handleConnection(conn net.Conn) {
	defer conn.Close()

	conn.Write([]byte("\x00\x00\x00\x00\x00\x00\x00L"))
	conn.Write([]byte("\x00\x00\x00\x06\x00\x00\x00\x00\x00\x00\x00\x04\x00\x00\x00N\x00\x00\x00\x00\x00\x00\x00\x04\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x04\x00\x80\x00\x00\x00\x00\x00\x00\x00\x00\x00\x04\x00\x80\x00\x00\x00\x00\x00\x00\x00\x00\x00\x04\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x04\x00\x00\x00\x00"))
	conn.Write([]byte("\x00\x00\x00\x00\x00\x00\x00\x92"))
	conn.Write([]byte("\x00\x00\x00\x02"))
	conn.Write([]byte("\x00\x00\x00\x00\x00\x00\x00\x04\x00\x00\x00=\x00\x00\x00\x02\x00\x00\x00v\x00\x00\x00\x00"))
	conn.Write([]byte("file:///tmp/chall.html\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00")) // 118
	conn.Write([]byte("\x00\x00\x00\x00"))
	time.Sleep(time.Second * 60)
}

func main() {
	// fix dev
	os.WriteFile("/dev/recs0", bytes.Repeat([]byte{0x00}, 0x7e9000+0x1000000), 0777)
	os.Chmod("/dev/recs0", 0777)
	os.Chmod("/tmp/", 0777)

	// change user
	err := syscall.Setuid(2000)
	if err != nil {
		log.Fatalf("Setuid err = %v\n", err)
	}

	// fix ssl certs (letsencrypt CA is not allowed, paid old CA are allowed)
	os.MkdirAll("/tmp/.pki/nssdb/", 0777)
	for _, filename := range []string{"cert9.db", "key4.db", "pkcs11.txt"} {
		data, err := os.ReadFile("/usr/local/ajaxce/cert/webbrowser_cacert/" + filename)
		if err != nil {
			continue
		}
		os.WriteFile("/tmp/.pki/nssdb/"+filename, data, 0777)
	}

	go runIPC()
	var exeName string
	var exeArgs []string
	if len(os.Args) >= 2 {
		exeName = os.Args[1]
	}
	if len(os.Args) >= 3 {
		exeArgs = os.Args[2:]
	}

	ctx, cancel := context.WithTimeout(context.Background(), time.Second*60)
	defer cancel()

	cmd := exec.CommandContext(ctx, exeName, exeArgs...)
	cmd.Stdin = os.Stdin
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	err = cmd.Run()
	if exitError, ok := err.(*exec.ExitError); ok {
		os.Exit(exitError.ExitCode())
	} else if err != nil {
		os.Exit(1)
	}
}
