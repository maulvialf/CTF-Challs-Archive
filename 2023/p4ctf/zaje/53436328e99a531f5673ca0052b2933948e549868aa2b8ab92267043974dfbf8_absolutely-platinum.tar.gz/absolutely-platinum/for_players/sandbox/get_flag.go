package main

import _ "embed"

//go:embed flag.txt
var flagBuf []byte

func main() {
	println(string(flagBuf))
}
