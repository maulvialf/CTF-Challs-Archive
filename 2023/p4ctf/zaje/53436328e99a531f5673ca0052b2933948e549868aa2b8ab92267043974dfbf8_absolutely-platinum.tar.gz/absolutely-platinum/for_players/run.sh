#!/usr/bin/env bash

set -ex

if [[ ! -f ./sandbox.tar.gz ]];
then
  wget -O ./sandbox.tar.gz https://p4ctf2023.fra1.cdn.digitaloceanspaces.com/platinum/13b2d7a1ffb7935b73f63484d3cc095a/sandbox.tar.gz
fi

export DOCKER_BUILDKIT=0
docker import --platform=linux/arm32v7 ./sandbox.tar.gz p4ctf_chall_platinum:base
docker build -t p4ctf_chall_platinum:latest -f ./sandbox/Dockerfile ./sandbox/

# probably needed on x86 (uncomment if want qemu-arm)
if [[ "$(uname -m)" == "x86_64" ]]; then
  read -p "Do you want to install binfmt for ARM? (y/n) " answer
  if [[ "$answer" == "y" ]]; then
      docker run --privileged --rm tonistiigi/binfmt --install all
  else
      echo "Installation cancelled."
  fi
fi

docker-compose -p misc_platinum -f docker-compose.yml rm -f --stop
docker-compose -p misc_platinum -f docker-compose.yml build
docker-compose -p misc_platinum -f docker-compose.yml up -d
