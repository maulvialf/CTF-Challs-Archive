package main

import (
	"context"
	"embed"
	"encoding/json"
	"io"
	"io/fs"
	"log"
	"net/http"
	"os"
	"os/exec"
	"os/user"
	"path"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"
)

func pingHandle(w http.ResponseWriter, req *http.Request) {
	w.WriteHeader(200)
	w.Write([]byte("ok"))
}

type RunResponse struct {
	Formatted string         `json:"formatted,omitempty"`
	Events    []CompileEvent `json:"events,omitempty"`
}

type CompileEvent struct {
	Message string
	Kind    string // stdout / stderr
	Delay   time.Duration
}

type combinedEvent struct {
	mu     sync.Mutex
	events []CompileEvent
	now    time.Time
}

func (s *combinedEvent) GetResponse() RunResponse {
	return RunResponse{
		Formatted: "",
		Events:    s.events,
	}
}

func (s *combinedEvent) AddError(err error) {
	s.addEvent([]byte(err.Error()), "stderr")
}

func (s *combinedEvent) addEvent(b []byte, kind string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.events = append(s.events, CompileEvent{
		Message: string(b),
		Kind:    kind,
		Delay:   time.Since(s.now),
	})
}

func (s *combinedEvent) WriteKind(kind string) io.Writer {
	return &kindEvent{
		parent: s,
		kind:   kind,
	}
}

type kindEvent struct {
	parent *combinedEvent
	kind   string
}

func (s *kindEvent) Write(b []byte) (int, error) {
	s.parent.addEvent(b, s.kind)
	return len(b), nil
}

func runCodeHandle(w http.ResponseWriter, req *http.Request) {
	if req.Method != "POST" {
		w.Header().Set("x-error", "invalid method")
		w.WriteHeader(500)
		return
	}

	payload, err := io.ReadAll(req.Body)
	if err != nil {
		w.Header().Set("x-error", err.Error())
		w.WriteHeader(500)
		return
	}

	file, err := os.CreateTemp("", "p4ctf.*.nix")
	if err != nil {
		w.Header().Set("x-error", err.Error())
		w.WriteHeader(500)
		return
	}
	defer os.Remove(file.Name())

	_, err = file.Write(payload)
	if err != nil {
		w.Header().Set("x-error", err.Error())
		w.WriteHeader(500)
		return
	}

	ctx, cancel := context.WithTimeout(context.Background(), time.Second*60)
	defer cancel()

	c := exec.CommandContext(ctx, "/nix/var/nix/profiles/default/bin/nix-build", file.Name(), "--no-out-link")

	out := &combinedEvent{}
	out.now = time.Now()
	c.Stdout = out.WriteKind("stdout")
	c.Stderr = out.WriteKind("stderr")

	if err := c.Run(); err != nil {
		out.AddError(err)
		w.Header().Set("x-error", err.Error())
	}

	json.NewEncoder(w).Encode(out.GetResponse())
}

//go:embed frontend/build
var frontendPath embed.FS

func staticFS() http.FileSystem {
	fsys := fs.FS(frontendPath)
	html, err := fs.Sub(fsys, "frontend/build")
	if err != nil {
		log.Fatal(err)
	}
	return http.FS(html)
}

func isFileExists(fsH http.FileSystem, r *http.Request) bool {
	upath := r.URL.Path
	if !strings.HasPrefix(upath, "/") {
		upath = "/" + upath
	}
	upath = path.Clean(upath)
	if _, err := fsH.Open(upath); err != nil {
		return false
	}
	return true
}

func main() {
	var err error
	user, err := user.Lookup("user")
	if err != nil {
		log.Fatalf("user.Lookup err = %v\n", err)
	}
	userUid, _ := strconv.Atoi(user.Uid)

	err = syscall.Setuid(userUid)
	if err != nil {
		log.Fatalf("Setuid err = %v\n", err)
	}

	fsH := staticFS()
	handleFs := http.FileServer(fsH)

	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if !isFileExists(fsH, r) {
			r.URL.Path = "/404.html"
			handleFs.ServeHTTP(w, r)
			return
		}
		handleFs.ServeHTTP(w, r)
	})
	http.HandleFunc("/api/ping", pingHandle)
	http.HandleFunc("/api/run", runCodeHandle)
	err = http.ListenAndServe(":5900", nil)
	if err != nil {
		log.Fatalf("ListenAndServe err = %v\n", err)
	}
}
