
Endpoint `/api/run` pseudocode:
```python
@app.post('/api/run')
def handle_endpoint_run(req, resp):
    file_path = create_tmpfile("p4ctf.*.nix")
    write_file(file_path, req.body)
    out = exec_cmd("/nix/var/nix/profiles/default/bin/nix-build", args=[file_path, "--no-out-link"], timeout=60)
    resp.write_response(out)

def main():
    setuid("user")
    run.app(port=5900)
```

Where is flag:
```console
$ ls -al /Users/flag/
total 8
drwxr-x---  3 root  nixbld   96 Feb 26 20:46 .
drwxr-xr-x  7 root  admin   224 Feb 21 18:03 ..
-r--r-----  1 root  nixbld   18 Feb 26 20:40 flag.txt
```

How to run locally:
```console
$ # download qemu image (14GB for download!!!)
$ wget https://p4ctf2023.fra1.cdn.digitaloceanspaces.com/chall_nix/7ddf32e17a6ac5ce04a8ecbf782ca509/p4_chall_nix.img.PART.{00..13}
$ # verify checksum - wget https://p4ctf2023.fra1.cdn.digitaloceanspaces.com/chall_nix/7ddf32e17a6ac5ce04a8ecbf782ca509/p4_chall_nix.img.MD5.{00..13}
$ cat p4_chall_nix.img.PART.{00..13} > p4_chall_nix.img
# # verify md5sum - 4c6b0b652484b751a77dca3fbed150e8  p4_chall_nix.img

$ # with X11
$ chmod 777 /root/.Xauthority
# xhost +
$ docker run --rm \
    -v "$PWD/p4_chall_nix.img:/home/arch/OSX-KVM/mac_hdd_ng.img" \
    --network host \
    --device /dev/kvm \
    --device /dev/snd \
    -e RAM=4 \
    -e SMP=4 \
    -e CORES=4 \
    -e NOPICKER=true \
    -v /tmp/.X11-unix:/tmp/.X11-unix \
    -v /root/.Xauthority:/home/arch/.Xauthority \
    -e "DISPLAY=$DISPLAY" \
    -it patryk4815/osx-base:ventura

$ # without X11
$ docker run --rm \
    -v "$PWD/p4_chall_nix.img:/home/arch/OSX-KVM/mac_hdd_ng.img" \
    --network host \
    --device /dev/kvm \
    --device /dev/snd \
    -e RAM=4 \
    -e SMP=4 \
    -e CORES=4 \
    -e NOPICKER=true \
    -e EXTRA="-display none" \
    -it patryk4815/osx-base:ventura

$ # tcp:10022 - ssh
$ # tcp:5900 - chall server
# # admin:p4ctf (username / password)
# # user:p4ctf (username / password)
```
NOTE: on production we have disabled this account and ssh.
