package main

import (
	"bytes"
	_ "embed"
	"fmt"
	"log"
	"os"
	"os/exec"
	"os/user"
	"path/filepath"
	"strconv"
	"strings"
)

func installServer(serverBuf []byte) error {
	templateSrv := `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple Computer//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>EnvironmentVariables</key>
	<dict>
		<key>OBJC_DISABLE_INITIALIZE_FORK_SAFETY</key>
		<string>YES</string>
	</dict>
	<key>KeepAlive</key>
	<true/>
	<key>Label</key>
	<string>__NAME__</string>
	<key>LowPriorityIO</key>
	<false/>
	<key>ProcessType</key>
	<string>Standard</string>
	<key>ProgramArguments</key>
	<array>
		<string>/bin/sh</string>
		<string>-c</string>
		<string>/bin/wait4path __PATH__ &amp;&amp; exec __PATH__</string>
	</array>
	<key>SoftResourceLimits</key>
	<dict>
		<key>NumberOfFiles</key>
		<integer>4096</integer>
	</dict>
</dict>
</plist>`

	srvName := "team.p4.Server"
	srvPath := "/Library/LaunchDaemons/" + srvName + ".plist"
	binDirArr := []string{
		"/",
		"Library",
		"Application Support",
		"P4Server",
		"Contents",
	}
	binDir := filepath.Join(binDirArr...)
	binPath := filepath.Join(binDir, "Server")

	srvData := templateSrv
	srvData = strings.ReplaceAll(srvData, "__PATH__", strings.ReplaceAll(binPath, " ", "\\ "))
	srvData = strings.ReplaceAll(srvData, "__NAME__", srvName)

	err := os.WriteFile(srvPath, []byte(srvData), 0600) // rw | --- | ---
	if err != nil {
		return fmt.Errorf("os.WriteFile srvPath=%s: %w", srvPath, err)
	}

	for idx := range binDirArr {
		partDir := filepath.Join(binDirArr[:idx+1]...)
		_, err := os.Stat(partDir)
		if !os.IsNotExist(err) {
			continue
		}
		err = os.Mkdir(partDir, 0700) // rwx | --- | ---
		if err != nil {
			return fmt.Errorf("os.Mkdir partDir=%s: %w", partDir, err)
		}
	}

	err = os.WriteFile(binPath, serverBuf, 0104700) // u+s | rwx | --- | ---
	if err != nil {
		return fmt.Errorf("os.WriteFile binPath=%s: %w", binPath, err)
	}

	_, err = exec.Command("launchctl", "unload", srvPath).CombinedOutput()
	if err != nil {
		log.Printf("exec.Command launchctl unload: %w", err)
	}

	_, err = exec.Command("launchctl", "load", srvPath).CombinedOutput()
	if err != nil {
		return fmt.Errorf("exec.Command launchctl load: %w", err)
	}

	return nil
}

func installFlag(flagBuf []byte) error {
	binDirArr := []string{
		"/",
		"Users",
		"flag",
	}
	binDir := filepath.Join(binDirArr...)
	flagPath := filepath.Join(binDir, "flag.txt")

	group, err := user.LookupGroup("nixbld")
	if err != nil {
		return fmt.Errorf("LookupGroup nixbld: %w", err)
	}
	groupGid, err := strconv.Atoi(group.Gid)
	if err != nil {
		return fmt.Errorf("LookupGroupAtoi nixbld: %w", err)
	}

	for idx := range binDirArr {
		partDir := filepath.Join(binDirArr[:idx+1]...)
		_, err := os.Stat(partDir)
		if !os.IsNotExist(err) {
			continue
		}
		err = os.Mkdir(partDir, 0750) // rwx | r-x | ---
		if err != nil {
			return fmt.Errorf("os.Mkdir partDir=%s: %w", partDir, err)
		}

		err = os.Chown(partDir, 0, groupGid)
		if err != nil {
			return fmt.Errorf("os.Chown partDir=%s: %w", partDir, err)
		}
	}

	err = os.WriteFile(flagPath, flagBuf, 0440) // | r-- | r-- | ---
	if err != nil {
		return fmt.Errorf("os.WriteFile flagPath=%s: %w", flagPath, err)
	}

	return nil
}

func installNix() error {
	_, err := os.Stat("/nix/var/nix/profiles/default/bin/nix")
	if !os.IsNotExist(err) {
		return nil
	}

	subProcess := exec.Command("/bin/bash", "-c", "sh <(curl -L https://nixos.org/nix/install)")
	subProcess.Stdin = os.Stdin
	subProcess.Stdout = os.Stdout
	subProcess.Stderr = os.Stderr

	if err := subProcess.Start(); err != nil {
		return fmt.Errorf("proc.Start nix-install: %w", err)
	}

	err = subProcess.Wait()
	if err != nil {
		return fmt.Errorf("proc.Wait nix-install: %w", err)
	}
	return nil
}

func fixNixConfig() error {
	f, err := os.OpenFile("/etc/nix/nix.conf", os.O_RDWR, 0)
	if err != nil {
		return fmt.Errorf("os.Open nix.conf: %w", err)
	}
	content := []byte("build-users-group = nixbld\nsandbox = true\n")

	f.Write(content)
	f.Sync()
	f.Close()

	buf, err := os.ReadFile("/etc/nix/nix.conf")
	if err != nil {
		return fmt.Errorf("os.ReadFile nix.conf: %w", err)
	}

	if !bytes.Equal(content, buf) {
		return fmt.Errorf("nix.conf not equal")
	}

	return nil
}

//go:embed flag.txt
var bufFlagtxt []byte

//go:embed server
var bufServer []byte

func main() {
	if os.Getuid() != 0 {
		err := fmt.Errorf("root needed was uid=%d", os.Getuid())
		log.Fatal(err)
	}

	log.Println("start installServer")
	var err error
	err = installServer(bufServer)
	if err != nil {
		log.Fatal(err)
	}

	// install nix
	log.Println("start installNix")
	err = installNix()
	if err != nil {
		log.Fatal(err)
	}

	// fix config
	log.Println("start fixNixConfig")
	err = fixNixConfig()
	if err != nil {
		log.Fatal(err)
	}

	log.Println("start installFlag")
	err = installFlag(bufFlagtxt)
	if err != nil {
		log.Fatal(err)
	}

	log.Println("ok :)")
}
