#!/usr/bin/env bash

set -ex

# build frontend
pushd ./frontend

yarn install
yarn build

rm -rf node_modules
popd

# server http

GOOS=darwin GOARCH=amd64 CGO_ENABLED=1 go build -ldflags "-s -w" -buildmode=pie -trimpath -o server_amd64 server.go
GOOS=darwin GOARCH=arm64 CGO_ENABLED=1 go build -ldflags "-s -w" -buildmode=pie -trimpath -o server_arm64 server.go

lipo -create -output server server_amd64 server_arm64
rm -rf frontend/build

# installer

GOOS=darwin GOARCH=amd64 CGO_ENABLED=1 go build -ldflags "-s -w" -buildmode=pie -trimpath -o install_amd64 install.go
GOOS=darwin GOARCH=arm64 CGO_ENABLED=1 go build -ldflags "-s -w" -buildmode=pie -trimpath -o install_arm64 install.go

lipo -create -output install install_amd64 install_arm64

rm server server_amd64 server_arm64 install_amd64 install_arm64
