import StatusBar from './StatusBar';
export default StatusBar;
