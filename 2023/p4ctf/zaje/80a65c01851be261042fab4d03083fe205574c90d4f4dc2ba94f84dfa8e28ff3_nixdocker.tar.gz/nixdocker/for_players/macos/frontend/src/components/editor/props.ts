import * as monaco from 'monaco-editor';
import {MonacoSettings} from '~/services/config';
import {getDefaultFontFamily, getFontFamily} from '~/services/fonts';

export const LANGUAGE_NIXLANG = 'nix';

export const DEMO_CODE = "{\n    pkgs ? import <nixpkgs> {}\n}:\nlet\n    hello = pkgs.runCommand \"hello\" {} ''\n        ls -al /\n    '';\nin hello";

// stateToOptions converts MonacoState to IEditorOptions
export const stateToOptions = (state: MonacoSettings): monaco.editor.IEditorOptions => {
  const {
    selectOnLineNumbers,
    mouseWheelZoom,
    smoothScrolling,
    cursorBlinking,
    fontLigatures,
    cursorStyle,
    contextMenu
  } = state;
  return {
    selectOnLineNumbers,
    mouseWheelZoom,
    smoothScrolling,
    cursorBlinking,
    cursorStyle,
    fontLigatures,
    fontFamily: state.fontFamily ? getFontFamily(state.fontFamily) : getDefaultFontFamily(),
    showUnused: true,
    automaticLayout: true,
    minimap: {enabled: state.minimap},
    contextmenu: contextMenu,
  };
};
