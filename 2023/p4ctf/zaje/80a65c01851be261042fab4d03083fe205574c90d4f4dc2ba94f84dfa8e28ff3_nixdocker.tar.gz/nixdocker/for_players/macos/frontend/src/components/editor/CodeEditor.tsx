import React from 'react';
import MonacoEditor from 'react-monaco-editor';
import * as monaco from 'monaco-editor';
import {editor, IKeyboardEvent} from 'monaco-editor';
import {
  createVimModeAdapter,
  StatusBarAdapter,
  VimModeKeymap
} from '~/plugins/vim/editor';
import {attachCustomCommands} from './commands';

import {
  Connect,
  newFileChangeAction,
  newMarkerAction,
  newSnippetLoadDispatcher,
  runFileDispatcher,
} from '~/store';
import {LANGUAGE_NIXLANG, stateToOptions} from './props';
import {getTimeNowUsageMarkers} from './utils';
import {RuntimeType} from "@services/config";
import {EditorDidMount} from "react-monaco-editor/src/types";

const ANALYZE_DEBOUNCE_TIME = 500;

interface CodeEditorState {
  code?: string
  loading?: boolean
}

@Connect(s => ({
  code: s.editor.code,
  fileName: s.editor.fileName,
  darkMode: s.settings.darkMode,
  vimModeEnabled: s.settings.enableVimMode,
  isServerEnvironment: RuntimeType.isServerRuntime(s.settings.runtime),
  loading: s.status?.loading,
  options: s.monaco,
  vim: s.vim,
}))
export default class CodeEditor extends React.Component<any, CodeEditorState> {
  private _previousTimeout: any;
  private editorInstance?: editor.IStandaloneCodeEditor;
  private vimAdapter?: VimModeKeymap;
  private vimCommandAdapter?: StatusBarAdapter;

  setLangSyntax(monaco: Parameters<EditorDidMount>[1]) {
    // monaco.languages.register({
    //   id: 'nix',
    // });
    //
    // monaco.languages.setMonarchTokensProvider('nix', {
    //   tokenizer: {
    //     root: [
    //       [/[a-zA-Z_][a-zA-Z0-9_-]*/, { token: 'identifier' }],
    //       [/\b(?:if|then|else|let|in)\b/, { token: 'keyword' }],
    //       [/\b(?:null|true|false)\b/, { token: 'constant.language' }],
    //       [/\b(?:assert|import|builtins|rec)\b/, { token: 'support.function' }],
    //       [/\b(?:with|inherit|override)\b/, { token: 'storage.type' }],
    //       [/\b\d+\b/, { token: 'constant.numeric' }],
    //       [/"[^"]*"/, { token: 'string' }],
    //       [/#.*$/, { token: 'comment' }],
    //       [/[\{\[\(]/, { token: 'delimiter.bracket' }],
    //       [/[\}\]\)]/, { token: 'delimiter.bracket' }]
    //     ]
    //   }
    // });
    // monaco.languages.setMonarchTokensProvider(languageId, {
    //   keywords: ['if', 'then', 'else', 'assert', 'with', 'let', 'in', 'rec'],
    //   operators: ['=', '?', ':', '@', '//', '.', '+', '==', '!=', '!', '|', '||', '&&'],
    //   brackets: [
    //     {open: '{', close: '}', token:'delimiter.curly'},
    //     {open: '[', close: ']', token:'delimiter.square'},
    //     {open: '(', close: ')', token:'delimiter.parenthesis'},
    //   ],
    //   tokenizer: {
    //     root: [
    //       {include: 'string'},
    //       {include: 'comment'},
    //       // {include: 'set'},
    //       // {include: 'list'},
    //       // {include: 'number'},
    //       // {include: 'operator'},
    //       // {include: 'keyword'},
    //       [/[a-zA-Z_$][\w$]*/, {token: 'identifier'}],
    //       [/\s+/, {token: 'whitespace'}],
    //     ],
    //     string: [
    //       {
    //         regex: /'''/,
    //         action: {token: 'string', next: 'multi_string'},
    //       },
    //       {
    //         regex: /"/,
    //         action: {token: 'string', next: 'double_quoted_string'},
    //       },
    //       {
    //         regex: /'/,
    //         action: {token: 'string', next: 'single_quoted_string'},
    //       },
    //     ],
    //     multi_string: [
    //       {
    //         regex: /.*'''/,
    //         action: {token: 'string', next: 'root'},
    //       },
    //       [/.*$/, 'string'],
    //     ],
    //     double_quoted_string: [
    //       {
    //         regex: /"/,
    //         action: {token: 'string', next: 'root'},
    //       },
    //       {regex: /[^\\$\"]+/, action: 'string'},
    //       {regex: /\\./, action: 'string'},
    //       {regex: /\$\{/, action: {token: 'delimiter.bracket', next: 'root'}},
    //       {regex: /\$/, action: {token: 'dollar', next: 'root'}},
    //     ],
    //     single_quoted_string: [
    //       {
    //         regex: /'/,
    //         action: {token: 'string', next: 'root'},
    //       },
    //       {regex: /[^\\']+/, action: 'string'},
    //       {regex: /\\./, action: 'string'},
    //     ],
    //     comment: [
    //       {
    //         regex: /\/\*/,
    //         action: {token: 'comment', next: 'multiline_comment'},
    //       },
    //       {regex: /#.*/, action: 'comment'},
    //     ],
    //     multiline_comment: [
    //       {
    //         regex: /.*\*\//,
    //         action: {token: 'comment', next: 'root'},
    //       },
    //       [/.*$/, 'comment'],
    //     ],
    //     // set: [
    //     //   {
    //     //     regex: /{/,
    //     //     action: {token: 'delimiter.curly', next: 'set_inner'},
    //     //   },
    //     // ],
    //     // set_inner: [
    //     //   {regex: /}/, action: {token: 'delimiter.curly', next: 'root'}},
    //     //   {include: 'root'},
    //     //   {regex: /;/, action: {token: 'delimiter.semicolon'}},
    //     //   {regex: /=/, action: {token: 'operator'}},
    //     //   {regex: /[a-zA-Z_$][\w$]*/, action: {token: 'identifier'}},
    //     // ]
    //   }});
    //
    // // monaco.languages.setMonarchTokensProvider(languageId, {
    // //   tokenizer: {
    //     root: [
    //       // multiline string
    //       [/''.*?''/, 'string'],
    //
    //       // strings
    //       [/"/, { token: 'string.quote', bracket: '@open', next: '@string' }],
    //       [/'/, { token: 'string.quote', bracket: '@open', next: '@string' }],
    //
    //       // comments
    //       [/#.*$/, 'comment'],
    //
    //       // operators
    //       [/\+\+|&&|\|\||\?|:|\[|\]|\{|\}|\(|\)|\,|;/, 'delimiter'],
    //       [/<|>|=|\+|\-|\*|\/|\^|%|!|@|&|~|\.|\||\\/, 'operator'],
    //
    //       // numbers
    //       [/\b\d+\b/, 'number'],
    //
    //       // keywords
    //       [
    //         /\b(?:rec|let|in|if|then|else|assert|with|inherit|or|and|import)\b/,
    //         'keyword',
    //       ],
    //
    //       // booleans and null
    //       [/\b(?:true|false|null)\b/, 'constant'],
    //
    //       // paths
    //       [/\/(?:[a-zA-Z0-9\-\._~!$&'()*+,;=:@]+\/)*[a-zA-Z0-9\-\._~!$&'()*+,;=:@]+/, 'string.path'],
    //
    //       // variables and attributes
    //       [/\b[a-zA-Z_][a-zA-Z0-9_\']*:/, 'attribute'],
    //       [/\b[a-zA-Z_][a-zA-Z0-9_\']*/, 'variable'],
    //
    //       // everything else
    //       [/[^\s]+/, 'text'],
    //     ],
    //
    //     string: [
    //       [/[^\\\$\"\'\n]+/, 'string'],
    //       [/\\./, 'string.escape.invalid'],
    //       [
    //         /[\$]/,
    //         {
    //           cases: {
    //             '$S2=="': { token: 'string', bracket: '@close', next: '@pop' },
    //             '@default': 'string',
    //           },
    //         },
    //       ],
    //       [
    //         /["']/,
    //         {
    //           cases: {
    //             '$#==$S2': { token: 'string', bracket: '@close', next: '@pop' },
    //             '@default': 'string',
    //           },
    //         },
    //       ],
    //       [/$/, 'string', '@pop'],
    //       [/[^\\"\'\$\n]+/, 'string'],
    //     ],
    //   },
    // });

    // monaco.languages.setMonarchTokensProvider(languageId, {
    //   // Set defaultToken to invalid to see what you do not tokenize yet
    //   // defaultToken: 'invalid',
    //
    //   keywords: [
    //     'assert', 'else', 'if', 'import', 'in', 'inherit', 'let', 'or', 'rec', 'then', 'with'
    //   ],
    //
    //   typeKeywords: [
    //     'null', 'true', 'false'
    //   ],
    //
    //   operators: [
    //     '=', '!=', '<', '<=', '>', '>=', '?', '->', '@', '.', '//', '/.', '::', ':', '?'
    //   ],
    //
    //   brackets: [
    //     {open: '{', close: '}', token: 'delimiter.curly'},
    //     {open: '[', close: ']', token: 'delimiter.square'},
    //     {open: '(', close: ')', token: 'delimiter.parenthesis'}
    //   ],
    //
    //   // Multi-line strings
    //   tokenizer: {
    //     root: [
    //       [/"{3}(?!")(?:[^\\]|\\[\s\S])*?"{3}/, 'string'],
    //       [/''(?:[^']|'')*''/, 'string'],
    //       [/"/, 'string', '@string."'],
    //       [/''/, 'string', '@string.\'\''],
    //       [/[\{\[\(]/, '@brackets'],
    //       [/[ \t\r\n]+/, ''],
    //       [/#[^\n]*\n/, 'comment'],
    //       [/(import)(\s+)(.+)(\s+)(\{)/, ['keyword', '', 'string.import', '', '@brackets']],
    //       [/(import)(\s+)(.+)/, ['keyword', '', 'string.import']],
    //       [/(with|let)(\s+)(.+)(\s*)(;)/, ['keyword', '', 'string', '', 'delimiter']],
    //       [/(assert)(\s+)(.+)(\s*)(;)/, ['keyword', '', 'string', '', 'delimiter']],
    //       [/(?:rec)(\s+)/, 'keyword.rec'],
    //       [/(true|false|null)\b/, 'type'],
    //       [/(if|then|else)(?=\s)/, 'keyword'],
    //       [/(in|or)(?=\s)/, 'keyword'],
    //       [/(function)(\s+)(\w+)?(\s*)(\{)/, ['keyword', '', 'variable', '', '@brackets']],
    //       [/(function)(\s*)(\{)/, ['keyword', '', '@brackets']],
    //       [/([a-zA-Z-]+)(\s*)(\{)/, ['variable', '', '@brackets']],
    //       [/([a-zA-Z-]+)(\s*)(\()/, ['variable', '', '@brackets']],
    //       [/([a-zA-Z-]+)(\s+)(\w+)/, ['variable', '', 'string']],
    //       [/[0-9]+\b/, 'number'],
    //       [/([a-zA-Z-_]+)\b/, 'variable'],
    //       [/[=<>:]+/, 'operator'],
    //       [/\./, 'delimiter'],
    //       [/\|\|/, 'operator'],
    //       [/\|/, 'operator'],
    //       [/\//, 'operator']
    //     ],
    //
    //     string: [
    //       [/[^\\"]+/, 'string'],
    //       [/\\./, 'string.escape.invalid'],
    //       [/""/, 'string'],
    //       [/"/, 'string', '@pop'],
    //     ]
    //   }
    // });;
  }

  editorDidMount(editorInstance: editor.IStandaloneCodeEditor, monacoInc: monaco.editor.IEditorConstructionOptions) {
    this.editorInstance = editorInstance;

    this.setLangSyntax(monacoInc as any);

    editorInstance.onKeyDown(e => this.onKeyDown(e));
    const [ vimAdapter, statusAdapter ] = createVimModeAdapter(
      this.props.dispatch,
      editorInstance
    );
    this.vimAdapter = vimAdapter;
    this.vimCommandAdapter = statusAdapter;

    if (this.props.vimModeEnabled) {
      console.log('Vim mode enabled');
      this.vimAdapter.attach();
    }

    const actions = [
      {
        id: 'clear',
        label: 'Reset contents',
        contextMenuGroupId: 'navigation',
        run: () => {
          this.props.dispatch(newSnippetLoadDispatcher());
        }
      },
      {
        id: 'run-code',
        label: 'Build And Run Code',
        contextMenuGroupId: 'navigation',
        keybindings: [
          monaco.KeyMod.CtrlCmd | monaco.KeyCode.Enter
        ],
        run: (ed, ...args) => {
          this.props.dispatch(runFileDispatcher);
        }
      },
      // {
      //   id: 'format-code',
      //   label: 'Format Code (goimports)',
      //   contextMenuGroupId: 'navigation',
      //   keybindings: [
      //     monaco.KeyMod.CtrlCmd | monaco.KeyMod.Shift | monaco.KeyCode.KeyF
      //   ],
      //   run: (ed, ...args) => {
      //     this.props.dispatch(formatFileDispatcher);
      //   }
      // }
    ];

    // Register custom actions
    actions.forEach(action => editorInstance.addAction(action));
    attachCustomCommands(editorInstance);
    editorInstance.focus();
  }

  private isFileOrEnvironmentChanged(prevProps) {
    return (prevProps.isServerEnvironment !== this.props.isServerEnvironment) ||
      (prevProps.fileName !== this.props.fileName);
  }

  private applyVimModeChanges(prevProps) {
    if (prevProps?.vimModeEnabled === this.props.vimModeEnabled) {
      return
    }

    if (this.props.vimModeEnabled) {
      console.log('Vim mode enabled');
      this.vimAdapter?.attach();
      return;
    }

    console.log('Vim mode disabled');
    this.vimAdapter?.dispose();
  }

  componentDidUpdate(prevProps) {
    if (this.isFileOrEnvironmentChanged(prevProps)) {
      // Update editor markers on file or environment changes;
      this.doAnalyze(this.props.code);
    }

    this.applyVimModeChanges(prevProps);
  }

  componentWillUnmount() {
    this.vimAdapter?.dispose();
  }

  onChange(newValue: string, _: editor.IModelContentChangedEvent) {
    this.props.dispatch(newFileChangeAction(newValue));
    this.doAnalyze(newValue);
  }

  private doAnalyze(code: string) {
    if (this._previousTimeout) {
      clearTimeout(this._previousTimeout);
    }

    this._previousTimeout = setTimeout(async () => {
      this._previousTimeout = null;

      // Code analysis contains 2 steps that run on different conditions:
      // 1. Run Go worker if it's available and check for errors
      // 2. Add warnings to `time.Now` calls if code runs on server.
      const promises = [
        this.props.isServerEnvironment ? (
          Promise.resolve(getTimeNowUsageMarkers(code, this.editorInstance!))
        ) : null
      ].filter(p => !!p);

      const results = await Promise.allSettled(promises);
      const markers = results.flatMap(r => {
        // Can't do in beautiful way due of TS strict checks.
        if (r.status === 'rejected') {
          console.error(r.reason);
          return [];
        }

        return r.value ?? [];
      });

      editor.setModelMarkers(
        this.editorInstance?.getModel() as editor.ITextModel,
        this.editorInstance?.getId() as string,
        markers
      );
      this.props.dispatch(newMarkerAction(markers));
    }, ANALYZE_DEBOUNCE_TIME);
  }

  private onKeyDown(e: IKeyboardEvent) {
    const {vimModeEnabled, vim} = this.props;
    if (!vimModeEnabled || !vim?.commandStarted) {
      return;
    }

    this.vimCommandAdapter?.handleKeyDownEvent(e, vim?.keyBuffer);
  }

  render() {
    const options = stateToOptions(this.props.options);
    return (
      <MonacoEditor
        language={LANGUAGE_NIXLANG}
        theme={this.props.darkMode ? 'vs-dark' : 'vs-light'}
        value={this.props.code}
        options={options}
        onChange={(newVal, e) => this.onChange(newVal, e)}
        editorDidMount={(e, m: any) => this.editorDidMount(e, m)}
      />
    );
  }
}
