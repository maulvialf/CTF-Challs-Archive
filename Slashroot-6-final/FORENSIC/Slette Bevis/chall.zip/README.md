$ truncate -s -5 pass.txt
