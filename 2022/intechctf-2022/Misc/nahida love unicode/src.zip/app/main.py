import discord
import os
import string
import random

TOKEN = os.environ['TOKEN']
FLAG = os.environ['FLAG']
RESPONSE = [
    "hello...", "uhm... how are you?", "have you completed the quest?",
    "I hope you can complete this quest...", "I hope you can show me the correct answer...",
    "I love unicode character UwU", "you seem like a nice person...",
    "uhmm..."
]


class UniLove(object):
    def check(u):
        nahida = 'NAHIDA'
        for cf in ["strip", "lower"]:
            if getattr(str, cf)(nahida) == u:
                return False
            for c in u:
                if c in string.ascii_uppercase:
                    return False
        return nahida.upper() == u.upper()

    def main(username):
        if not UniLove.check(username):
            message = random.choice(RESPONSE)
            return f"{message}"
        else:
            return (f"Thank you for help me, onichan!(ﾉ◕ヮ◕)ﾉ*:・ﾟ✧\n{FLAG}")


class MyClient(discord.Client):
    async def on_ready(self):
        print(f'Logged on as {self.user}!')

    async def on_message(self, message: discord.Message):
        if str(message.channel.type) != 'private' or message.author == self.user:
            return
        outmsg = UniLove.main(message.content)
        await message.channel.send(outmsg)


intents = discord.Intents.default()
intents.message_content = True
client = MyClient(intents=intents)
client.run(TOKEN)
