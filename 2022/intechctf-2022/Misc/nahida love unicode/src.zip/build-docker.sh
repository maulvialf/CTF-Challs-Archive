#!/bin/bash
export name="nahidaloveunicode"
docker build --tag=$name .
docker run --rm --name=$name $name