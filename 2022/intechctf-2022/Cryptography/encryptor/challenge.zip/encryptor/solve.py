from pwn import xor

def banner():
    print("""=======================================
welcome to message encryptor/decryptor
=======================================
choose one of the following options:
\033[33m
1.) encrypt
2.) decrypt\033[37m
=======================================""")

def enc(flag):
    enc = b''
    enc2 = b''
    for i in range(len(flag)):
        enc += xor(flag[i].encode(), i)
    for i in range(int(len(flag)/2)):
        enc2 += chr(enc[i]).encode() if i % 5 == 5 else chr(enc[i] - 1).encode()
        enc2 += chr(enc[eval(f'-{i+1}')]).encode()
    open('enc_message.txt', 'wb').write(enc2)


def dec(enc):
    print("Accidently delete the decryption function, can you help me to fix it?")
    

def main():
    banner()
    while True:
        try:
            choice = int(input("choose method \033[33m>>>\033[39m "))
            if int(choice) == 1:
                msg = input("enter the message: ")
                if len(msg)%2 != 0:
                    print("encrypted message should be even!")
                    continue
                enc(msg)
                print("message encrypted successfully!")
                exit("=======================================")
            else:
                encrypted = open('enc_message.txt', 'rb').read()
                dec(encrypted)
                exit("=======================================")
        except ValueError:
            print("invalid input, please input number above")
            continue
        except KeyboardInterrupt:
            print("\nbye")
            exit("=======================================")

if __name__ == "__main__":
    main()