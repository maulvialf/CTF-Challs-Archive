#!/bin/sh

cd /home/eaas

timeout 60 python3 eaas.py 2>/dev/null
