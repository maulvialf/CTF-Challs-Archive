import json
import os
import base64
import re
import pbkdf2
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from Crypto.Hash import SHA512, SHA3_512


class Tenjin():

    mode_map = {
        'cbc': AES.MODE_CBC
    }

    hash_map = {
        '1': SHA512,
        '2': SHA3_512
    }

    def __init__(self, key):
        self.key = key

    def __encrypt(self, plaintext, iv, mode):

        plaintext = pad(plaintext, 16)
        aes = AES.new(self.key, self.mode_map[mode], iv)

        return aes.encrypt(plaintext)

    def __decrypt(self, ciphertext, iv, mode):

        aes = AES.new(self.key, self.mode_map[mode], iv)
        plaintext = aes.decrypt(ciphertext)

        return unpad(plaintext, 16)

    def __hash(self, data, hash):

        hkey = pbkdf2.PBKDF2(self.key, self.key, iterations=2000).read(32)
        hmac = self.hash_map[hash].new(hkey)
        hmac.update(data)

        return hmac.hexdigest()

    def __sanitize(self, data):
        matches = re.findall(r'\{[ -~]+\}', data.decode('ISO-8859-1'))
        if len(matches) > 0:
            return matches[0]

        return ""

    def sign(self, data, mode, hash):

        iv = os.urandom(16)
        encrypted_data = self.__encrypt(data, iv, mode)
        signature = self.__hash(encrypted_data, hash)

        content = {
            'mode': mode,
            'hash': hash,
            'iv': iv.hex(),
            'data': base64.urlsafe_b64encode(encrypted_data).decode(),
            'signature': signature
        }

        return base64.urlsafe_b64encode(json.dumps(content).encode())

    def verify(self, token):

        try:
            token = base64.urlsafe_b64decode(token)
            raw_data = json.loads(token)

            mode = raw_data['mode']
            hash = raw_data['hash']
            iv = bytes.fromhex(raw_data['iv'])
            encrypted_data = base64.urlsafe_b64decode(raw_data['data'])
            signature = raw_data['signature']

            data = self.__decrypt(encrypted_data, iv, mode)
            check = self.__hash(encrypted_data, hash)

            if check == signature:
                return json.loads(self.__sanitize(data))

        except Exception as e:
            return False
