import os
import json
import time
from fastapi import FastAPI, Request, HTTPException, Response
from pydantic import BaseModel
from Tenjin import Tenjin

app = FastAPI()

FLAG = open('flag.txt', 'r').read()
master_key = os.urandom(32)

admin = "Crypt0_N1nJA1337!"


class Credential(BaseModel):
    username: str
    role: str


tenjin = Tenjin(master_key)


@app.middleware("http")
async def middleware_header(request: Request, call_next):
    start = time.time()
    response = await call_next(request)
    proc_time = time.time() - start
    response.headers['x-process-time'] = str(proc_time)
    return response


@app.get("/")
def root_page():
    return {"version": "0.0.1"}


@app.post("/auth")
def get_token(credential: Credential):
    data = json.dumps({
        'username': credential.username,
        'role': 'user',
    })

    if credential.username == admin:
        raise HTTPException(status_code=403)

    token = tenjin.sign(data.encode(), 'cbc', '1')

    return token


@app.get("/auth")
def read_token(request: Request):
    token = request.headers.get('Authorization')

    if not token:
        raise HTTPException(status_code=403)

    decoded = tenjin.verify(token)

    if decoded:
        return decoded
    else:
        raise HTTPException(status_code=403)


@app.get("/flag")
def read_flag(request: Request):
    token = request.headers.get('Authorization')

    if not token:
        raise HTTPException(status_code=403)

    decoded = tenjin.verify(token)

    if decoded and decoded['username'] == admin and decoded['role'] == 'admin':
        return {'flag': FLAG}
    else:
        raise HTTPException(status_code=403)
