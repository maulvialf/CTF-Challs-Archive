

#include <iostream>
#include <string>
#include <vector>
#include <typeinfo>
#include <cstring>
#include <any>
#include <stdint.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>

#define TIMEOUT 60

class Vtuber {
    public:
        Vtuber():name(""),age(0) {
			type = "Vtuber";
		};

        Vtuber(int age) {
            this->age = age;
		};

        Vtuber(const Vtuber &v) {
            name=v.name;
            age=v.age;
            type=v.type;
            fandom_name=v.fandom_name;
        }

        std::string get_name() {
            return this->name;
        }

        int get_age() {
            return this->age;
        }

        std::string get_type() {
            return this->type;
        }

        std::string get_fandom_name() {
            return this->fandom_name;
        }

        virtual void stream() {
            std::cout << "何でもない" << std::endl;
        }

        virtual void info() {
			std::cout << "Name: " << name << std::endl;
			std::cout << "Age: " << age << std::endl;
            std::cout << "Type: " << type << std::endl;
            std::cout << "Fandom Name: " << fandom_name << std::endl;
        }

        virtual ~Vtuber() {
            name.clear();
            age = 0;
            type.clear();
            fandom_name.clear();
        }

    protected:
        std::string name;
        int age;
        std::string type;
        std::string fandom_name;
};

class Yakkai {
    public:
        Yakkai() {
        }

        void set_secret(std::string secret) {
            this->secret = new char[secret.length() + 1];
            memcpy(this->secret, secret.c_str(), secret.length());
        }

        std::string get_secret() {
            return this->secret;
        }

        virtual ~Yakkai() {
            delete[] this->secret;
        }

    protected:
        char *secret;
};

class Anti {
    public:
        Anti() {
        }

        void set_hate_sentence(std::string hate_sentence) {
            this->hate_sentence = new char[hate_sentence.length() + 1];
            memcpy(this->hate_sentence, hate_sentence.c_str(), hate_sentence.length());
        }

        std::string get_hate_sentence() {
            return this->hate_sentence;
        }

        virtual ~Anti() {
            delete[] this->hate_sentence;
        }
    protected:
        char *hate_sentence;
};

class Kamito: public Vtuber {
    public:
        Kamito(){
			type = "Oreo";
            is_papa = true;
		};
		
		Kamito(int age, std::string fandom_name, bool is_papa) {
            name = "Kamito";
			type = "Oreo";
			this->age = age;
			this->fandom_name = fandom_name;
            this->is_papa = is_papa;
		};

        void stream() {
            std::cout << "Solo pred season 2,3,4,5" << std::endl;
        }

        void info() {
            std::cout << "Name: " << name << std::endl;
			std::cout << "Age: " << age << std::endl;
            std::cout << "Type: " << type << std::endl;
            std::cout << "Fandom Name: " << fandom_name << std::endl;
            std::cout << "Is Papa: " << (is_papa ? "True" : "False") << std::endl;
        }

        bool get_is_papa() {
            return this->is_papa;
        }

        ~Kamito () {
            this->is_papa = false;
        }

    private:
        bool is_papa;
        friend class Hinano;
};

class Hinano: public Vtuber {
    public:
        Hinano(){
			type = "Apollo";
            is_mama = true;
		};
		
		Hinano(int age, std::string fandom_name, bool is_mama) {
            name = "Hinano";
			type = "Apollo";
			this->age = age;
			this->fandom_name = fandom_name;
            this->is_mama = is_mama;
		};

        void stream() {
            std::cout << "うるさい" << std::endl;
            std::cout << "(でもすき)" << std::endl;
        }

        void info() {
            std::cout << "Name: " << name << std::endl;
			std::cout << "Age: " << age << std::endl;
            std::cout << "Type: " << type << std::endl;
            std::cout << "Fandom Name: " << fandom_name << std::endl;
            std::cout << "Is Mama: " << (is_mama ? "True" : "False") << std::endl;
            std::cout << "Number of Children: " << this->children.size() << std::endl;
        }

        bool get_is_mama() {
            return this->is_mama;
        }

        template <class T>
        void add_child(T v) {
            this->children.push_back(v);
        }

        ~Hinano() {
            this->is_mama = false;       
        }

    private:
        bool is_mama;
        std::vector<Vtuber> children;
        friend class Kamito;
};

class Haseshin: public Vtuber {
    public:
        Haseshin(){
			type = "Oreapo no Kodomo";
            is_child = true;
		};
		
		Haseshin(int age, std::string fandom_name, bool is_child) {
            name = "Haseshin";
			type = "Oreapo no Kodomo";
			this->age = age;
			this->fandom_name = fandom_name;
            this->is_child = is_child;
		};

        void stream() {
            std::cout << "Technically not a vtuber but ok ignore this" <<  std::endl;
        }

        void info() {
            std::cout << "Name: " << name << std::endl;
			std::cout << "Age: " << age << std::endl;
            std::cout << "Type: " << type << std::endl;
            std::cout << "Fandom Name: " << fandom_name << std::endl;
            std::cout << "Is Child: " << (is_child ? "True" : "False") << std::endl;
        }

        ~Haseshin() {
            this->is_child = false;
        }

    private:
        bool is_child;
};

class Nazuna: public Vtuber, public Yakkai {
    public:
        Nazuna(){
			type = "Oreapo no Kodomo";
            is_child = true;
		};
		
		Nazuna(int age, std::string fandom_name, std::string secret, bool is_child) {
            name = "Nazuna";
			type = "Oreapo no Kodomo";
			this->age = age;
			this->fandom_name = fandom_name;
            this->is_child = is_child;
            this->set_secret(secret);
		};

        void stream() {
            std::cout << "Oreapo secret: " << this->get_secret() <<  std::endl;
        }

        void info() {
            std::cout << "Name: " << name << std::endl;
			std::cout << "Age: " << age << std::endl;
            std::cout << "Type: " << type << std::endl;
            std::cout << "Fandom Name: " << fandom_name << std::endl;
            std::cout << "Is Child: " << (is_child ? "True" : "False") << std::endl;
        }

        ~Nazuna() {
            this->is_child = false;
        }

    private:
        bool is_child;
};

class Giruru: public Vtuber, public Yakkai {
    public:
        Giruru(){
			type = "厄介リスナー";
		};
		
		Giruru(int age, std::string fandom_name, std::string secret, int yakkai_level) {
            name = "Giruru";
			type = "厄介リスナー";
			this->age = age;
			this->fandom_name = fandom_name;
            this->set_secret(secret);
            this->yakkai_level = yakkai_level;
		};

        void stream() {
            std::cout << "Oreapo secret: " << this->get_secret() <<  std::endl;
            std::cout << "Oreapo should get married" <<  std::endl;
        }

        void info() {
            std::cout << "Name: " << name << std::endl;
			std::cout << "Age: " << age << std::endl;
            std::cout << "Type: " << type << std::endl;
            std::cout << "Fandom Name: " << fandom_name << std::endl;
            std::cout << "Yakkai level: " << this->yakkai_level << std::endl;
        }

        ~Giruru() {
            this->yakkai_level = 0;
        }

    private:
        int yakkai_level;
        friend class Ramune;
};

class Ramune: public Vtuber {
    public: 
        Ramune(){
			type = "Pro gamer";
		};
		
		Ramune(int age, std::string fandom_name, std::string valorant_rank) {
            name = "Ramune";
			type = "Pro gamer";
			this->age = age;
			this->fandom_name = fandom_name;
            this->valorant_rank = valorant_rank;
		};

        void stream() {
            std::cout << "I've only been here 3 months!!!" <<  std::endl;
        }

        void info() {
            std::cout << "Name: " << name << std::endl;
			std::cout << "Age: " << age << std::endl;
            std::cout << "Type: " << type << std::endl;
            std::cout << "Fandom Name: " << fandom_name << std::endl;
            std::cout << "Valorant Rank: " << this->valorant_rank << std::endl;
        }

        ~Ramune() {
            this->valorant_rank.clear();
        }
    
    private:
        std::string valorant_rank;
        friend class Giruru;
};

class YamaP: public Vtuber {
    public: 
        YamaP(){
			type = "Comedian";
		};
		
		YamaP(int age, std::string fandom_name) {
            name = "Kaito";
			type = "Comedian";
			this->age = age;
			this->fandom_name = fandom_name;
		};

        void stream() {
            std::cout << "Their bullets flew like when I pee with my ******** in the morning" <<  std::endl;
            std::cout << "Quotes:" <<  std::endl;
            for(std::string i : this->embarrasing_quotes) {
                std::cout << i << std::endl;
            }

        }

        void info() {
            std::cout << "Name: " << name << std::endl;
			std::cout << "Age: " << age << std::endl;
            std::cout << "Type: " << type << std::endl;
            std::cout << "Fandom Name: " << fandom_name << std::endl;
        }

        void add_quote(std::string quote) {
            this->embarrasing_quotes.push_back(quote);
        }

        ~YamaP() {
        }
    
    private:
        std::vector<std::string> embarrasing_quotes;
        friend class LisaP;
};

class LisaP: public Vtuber, public Yakkai {
    public: 
        LisaP(){
			type = "Vocaloid Producer";
		};
		
		LisaP(int age, std::string fandom_name, std::string secret, double gahaha_level) {
            name = "Lisa";
			type = "Vocaloid Producer";
			this->age = age;
			this->fandom_name = fandom_name;
            this->set_secret(secret);
            this->gahaha_level = gahaha_level;
		};

        void stream() {
            std::cout << "Oreapo secret: " << this->get_secret() <<  std::endl;

            // This is some deep inside joke
            // Abaikan aja kalo gabisa baca
            std::cout << "今日も独りで密かに" << std::endl;
            std::cout << "泣いて泣いて泣きじゃくる" << std::endl;
            std::cout << "誰も見つけてくれやしないから " << std::endl;
            std::cout << "また密かに助けて欲しいと願うんだ" << std::endl;
            std::cout << std::endl;
            std::cout << "何回も無限に " << std::endl;
            std::cout << "叫んじゃうとね" << std::endl;
            std::cout << "またあなたの手によって" << std::endl;
            std::cout << "傷が増えちゃうから" << std::endl;
            std::cout << "だから叫ばない" << std::endl;
            std::cout << std::endl;
            std::cout << "そしてやがて時が来ると" << std::endl;
            std::cout << "真っ赤に染まる染まっていく" << std::endl;
            std::cout << "やがて時が経つと" << std::endl;
            std::cout << "私の赤い薔薇が黒く深くなって" << std::endl;
            std::cout << "ああ逃れられない運命" << std::endl;
            
        }

        void info() {
            std::cout << "Name: " << name << std::endl;
			std::cout << "Age: " << age << std::endl;
            std::cout << "Type: " << type << std::endl;
            std::cout << "Fandom Name: " << fandom_name << std::endl;
            std::cout << "GAHAHA level: " << this->gahaha_level << std::endl;
        }

        ~LisaP() {
            this->gahaha_level = 0;
        }
    
    private:
        double gahaha_level;
        friend class YamaP;
};

class MimiTaya: public Vtuber, public Yakkai {
    public: 
        MimiTaya(){
			type = "Bunny";
		};
		
		MimiTaya(int age, std::string fandom_name, std::string secret, unsigned long long cuteness) {
            name = "MimiTaya";
			type = "Bunny";
			this->age = age;
			this->fandom_name = fandom_name;
            this->set_secret(secret);
            this->cuteness = cuteness;
		};

        void stream() {
            std::cout << "Oreapo secret: " << this->get_secret() <<  std::endl;
            std::cout << "お前！" <<  std::endl;
            std::cout << "お前！" <<  std::endl;
            std::cout << "お前！" <<  std::endl;
            std::cout << "お前！" <<  std::endl;
            std::cout << "お前！" <<  std::endl;
            std::cout << "お前！" <<  std::endl;
            std::cout << "お前！" <<  std::endl;
        }

        void info() {
            std::cout << "Name: " << name << std::endl;
			std::cout << "Age: " << age << std::endl;
            std::cout << "Type: " << type << std::endl;
            std::cout << "Fandom Name: " << fandom_name << std::endl;
            std::cout << "Cuteness: " << this->cuteness << std::endl;
        }

        ~MimiTaya() {
            this->cuteness = 0;
        }
    
    private:
        unsigned long long cuteness;
        friend class Giruru;
};

class Sumire: public Vtuber, public Anti {
    public:
        Sumire(){
			this->type = "Oreapo Anti";
            this->cope_level = 100000000;
		};
		
		Sumire(int age, std::string fandom_name, std::string hate_sentence, unsigned long long cope_level) {
            name = "Sumire";
			type = "Oreapo Anti";
			this->age = age;
			this->fandom_name = fandom_name;
            this->set_hate_sentence(hate_sentence);
            this->cope_level = cope_level*10000;
		};

        void stream() {
            std::cout << this->get_hate_sentence() <<  std::endl;
            std::cout << this->get_hate_sentence() <<  std::endl;
            std::cout << this->get_hate_sentence() <<  std::endl;
        }

        void info() {
            std::cout << "Name: " << name << std::endl;
			std::cout << "Age: " << age << std::endl;
            std::cout << "Type: " << type << std::endl;
            std::cout << "Fandom Name: " << fandom_name << std::endl;
            std::cout << "Copium Level: " << this->cope_level << std::endl;
        }

        ~Sumire() {
            this->cope_level = 0;
        }

    private:
        unsigned long long cope_level;
};

void menu(){
	std::cout << std::endl;
	std::cout << "#####################################" << std::endl;
	std::cout << "            OREAPO TEETEE            " << std::endl;
	std::cout << "#####################################" << std::endl;
	std::cout << "1. Add Vtuber                        " << std::endl;
	std::cout << "2. Show Vtuber details               " << std::endl;
	std::cout << "3. Remove Vtuber from list           " << std::endl;
	std::cout << "4. Exit                              " << std::endl;
	std::cout << "#####################################" << std::endl;
	std::cout << std::endl;

};

std::vector<Vtuber*> vtubers;

void types(){
	std::cout << "-----------------" << std::endl;
	std::cout << " 1.Kamito        " << std::endl;
	std::cout << " 2.Hinano        " << std::endl;
	std::cout << " 3.Haseshin      " << std::endl;
	std::cout << " 4.Nazuna        " << std::endl;
	std::cout << " 5.Giruru        " << std::endl;
	std::cout << " 6.Ramune        " << std::endl;
	std::cout << " 7.YamaP         " << std::endl;
	std::cout << " 8.LisaP         " << std::endl;
	std::cout << " 9.MimiTaya      " << std::endl;
	std::cout << " 10.Sumire       " << std::endl;
	std::cout << "-----------------" << std::endl;
}

void list_mama() {
    std::vector<Vtuber*>::iterator iter;
    int i = 0;
    std::cout << "Valid Mama Fandoms: " << std::endl;
    for(iter = vtubers.begin(); iter != vtubers.end(); iter++,i++){
        if((**iter).get_type() == "Apollo") {
            std::cout << i << ". " << (**iter).get_fandom_name();
        }
    }
    std::cout << std::endl;
}

void add_func(){
	unsigned int choice;
	std::string fandom_name;
	int age;

	std::cout << "Age: ";
	std::cin >> age;

	std::cout << "Fandom name: ";
	std::cin.ignore();
	std::getline(std::cin, fandom_name);

	types();
	std::cout << "Choose vtuber: "; 
	std::cin >> choice;
	
	switch(choice){
		case 1:
            {
			int is_papa;
			std::cout << "Is Papa? (1:yes/0:no): ";
			std::cin >> is_papa;
			Kamito *temp = new Kamito(age, fandom_name, is_papa);
            vtubers.push_back(temp);
            break;
            }
		case 2:
            {
			int is_mama, ind;
			std::cout << "Is Mama? (1:yes/0:no): ";
			std::cin >> is_mama;
			Hinano *temp = new Hinano(age, fandom_name, is_mama);
            vtubers.push_back(temp);
            break;
            }
        case 3:
            {
			int is_child;
			std::cout << "Is Child? (1:yes/0:no): ";
			std::cin >> is_child;
			Haseshin *temp = new Haseshin(age, fandom_name, is_child);
            if(is_child) {
                uint ind;
                list_mama();
                std::cout << "Mama Index: ";
                std::cin >> ind;
                if(ind < vtubers.size() && (*vtubers[ind]).get_type() == "Apollo") {
                    Hinano *mama = dynamic_cast<Hinano*>(vtubers[ind]);
                    if(mama->get_is_mama()) {
                        mama->add_child(*temp);
                    }
                    else {
                        std::cout << "Invalid" << std::endl;   
                    }
                }
                else {
                    std::cout << "Invalid" << std::endl;   
                }
            }
            vtubers.push_back(temp);
            break;
            }
		case 4:
            {
			int is_child;
            std::string secret;
			std::cout << "Is Child? (1:yes/0:no): ";
			std::cin >> is_child;
            std::cout << "Oreapo secret: ";
			std::cin >> secret;
			Nazuna *temp = new Nazuna(age, fandom_name, secret, is_child);
            if(is_child) {
                uint ind;
                list_mama();
                std::cout << "Mama Index: ";
                std::cin >> ind;
                if(ind < vtubers.size() && (*vtubers[ind]).get_type() == "Apollo") {
                    Hinano *mama = dynamic_cast<Hinano*>(vtubers[ind]);
                    if(mama->get_is_mama()) {
                        mama->add_child(*temp);
                    }
                    else {
                        std::cout << "Invalid" << std::endl;   
                    }
                }
                else {
                    std::cout << "Invalid" << std::endl;   
                }
            }
            vtubers.push_back(temp);
            break;
            }
		case 5:
            {
			int yakkai_level;
            std::string secret;
			std::cout << "Yakkai level: ";
			std::cin >> yakkai_level;
            std::cout << "Oreapo secret: ";
			std::cin >> secret;
			Giruru *temp = new Giruru(age, fandom_name, secret, yakkai_level);
            vtubers.push_back(temp);
            break;
            }
		case 6:
            {
            std::string valorant_rank;
			std::cout << "Valorant rank: ";
			std::cin >> valorant_rank;
			Ramune *temp = new Ramune(age, fandom_name, valorant_rank);
            vtubers.push_back(temp);
            break;
            }
		case 7:
            {
            std::string again, quote;
			YamaP *temp = new YamaP(age, fandom_name);
            do {
                std::cout << "Quote: ";
                std::cin >> quote;
                temp->add_quote(quote);
                std::cout << "Add another quote? (y/n): ";
                std::cin >> again;
            } while(again == "y");
            vtubers.push_back(temp);
            break;
            }
		case 8:
            {
            double gahaha_level;
            std::string secret;
			std::cout << "GAHAHA level: ";
			std::cin >> gahaha_level;
            std::cout << "Oreapo secret: ";
			std::cin >> secret;
			LisaP *temp = new LisaP(age, fandom_name, secret, gahaha_level);
            vtubers.push_back(temp);
            break;
            }
		case 9:
            {
            unsigned long long cuteness;
            std::string secret;
			std::cout << "Cuteness: ";
			std::cin >> cuteness;
            std::cout << "Oreapo secret: ";
			std::cin >> secret;
			MimiTaya *temp = new MimiTaya(age, fandom_name, secret, cuteness);
            vtubers.push_back(temp);
            break;
            }
		case 10:
            {
            unsigned long long cope_level;
            std::string hate_sentence;
			std::cout << "Cope Level: ";
			std::cin >> cope_level;
            std::cout << "Hate sentence: ";
			std::cin >> hate_sentence;
			Sumire *temp = new Sumire(age, fandom_name, hate_sentence, cope_level);
            vtubers.push_back(temp);
            break;
            }
		default:
			std::cout << "Invaild choice" << std::endl;
			return;
	}

	return;

};

void delete_func(){
	unsigned int ind;
	if(vtubers.size() == 0){
		std::cout << "Invalid" << std::endl;
		return;
	}
	std::cout << "Index: ";
	std::cin >> ind;
	if(ind >= vtubers.size()){
		std::cout << "Invalid Index" << std::endl;
		return;
	}
	delete vtubers[ind];
	vtubers.erase(vtubers.begin()+ind);
    return;
}

void list_func(){
	std::vector<Vtuber*>::iterator iter;
	int i = 0;
	for(iter = vtubers.begin(); iter != vtubers.end(); iter++,i++){
		std::cout << i << ". " << (**iter).get_fandom_name() << std::endl;;
	}
	std::cout << std::endl;
}

void print_func(){
	unsigned int ind;
	if(vtubers.size() == 0){
		std::cout << "Invalid" << std::endl;
		return;
	}
	std::cout << "Index: ";
	std::cin >> ind;
	if(ind >= vtubers.size()){
		std::cout << "Invalid Index" << std::endl;
		return;
	}
	std::cout << "Details:" << std::endl;
	vtubers[ind]->info();
	std::cout << std::endl;
	vtubers[ind]->stream();
	return;
}

void init(){
	setvbuf(stdout,0,2,0);
	srand(time(NULL));
}

int main() {
    unsigned int choice;
	init();
	while(1){
		menu();
		std::cout << "Your choice: ";
		std::cin >> choice;
		if(!std::cin.good()){
			std::cout << "format error !" << std::endl;
			exit(0);
		}
		switch(choice){
			case 1:
				add_func();
				break;
			case 2:
				list_func();
				print_func();
				break;
			case 3:
				list_func();
				delete_func();
				break;
			case 4:
				std::cout << "Goodbye" << std::endl;
				exit(0);
				break;
			default:
				std::cout << "Invaild choice" << std::endl;
				break;


		}

	}
    return 0;
}