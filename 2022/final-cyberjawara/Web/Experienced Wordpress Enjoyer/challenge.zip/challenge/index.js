'use strict';

const express = require('express');
const puppeteer = require('puppeteer');

const PORT = 3000;
const HOST = '0.0.0.0';
const USERNAME = "donomanager";
const PASSWORD = "PLACEHOLDER_VALUE";
const LOGIN_URL = "http://IP_SERVER:8787/wp-admin";

function delay(time) {
  return new Promise(resolve => setTimeout(resolve, time));
} 

async function visit(url){
  const browser = await puppeteer.launch(
    {
      args: ['--no-sandbox', '--disable-setuid-sandbox'],
      executablePath: '/usr/bin/chromium'
    }
  );

  console.log("Try login");
  const page = await browser.newPage();
  await page.goto(LOGIN_URL, {waitUntil: 'networkidle2'});

  console.log("Inputting login creds");
  await page.type("#user_login", USERNAME);
  await page.type("#user_pass", PASSWORD);
  await page.click("#wp-submit");

  await page.waitForNavigation({waitUntil: 'networkidle2'});
  console.log("Login success");

  const urlx = await page.url();
  console.log(urlx);

  const page2 = await browser.newPage();

  try {
    await page2.goto(url);
    console.log("Visit " + url + " SUCCESS");
  }
  catch (e){
    console.log("Visit " + url + " ERROR");
  }
  console.log("browser close");
  await browser.close();
}

const app = express();

app.get('/', (req, res) => {
  var url = req.query.url;
  if (url){
    if (url.startsWith("http") && url.length <= 46){
      visit(url);
      res.send("visit process");
    }
    else{
      res.send("only accept http and certain length of url");
    }

  }
  else{
    res.send("no visit")
  }
});

app.listen(PORT, HOST, () => {
  console.log(`Running on http://${HOST}:${PORT}`);
});