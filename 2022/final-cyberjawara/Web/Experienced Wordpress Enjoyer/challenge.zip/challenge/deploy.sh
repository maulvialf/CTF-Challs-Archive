#!/bin/bash

make clean
make wordpress_install
make clean
make wordpress_reinstall