#!/bin/sh

docker-compose build
docker-compose up -d
docker-compose exec php-apache composer install
docker-compose exec php-apache cp .env.example .env
docker-compose exec php-apache php artisan key:generate
docker-compose exec php-apache php artisan migrate:fresh --seed
docker-compose exec chmod -R 777 storage
docker-compose exec chmod -R 777 resources/photos

if [ "$1" ]; then
  # Put flag in / directory
  filename="/flag-`cat /dev/urandom | base64 | head -c 32 |  tr -d '/+'`.txt"
  docker-compose exec php-apache sh -c "echo $1 > $filename"
fi

