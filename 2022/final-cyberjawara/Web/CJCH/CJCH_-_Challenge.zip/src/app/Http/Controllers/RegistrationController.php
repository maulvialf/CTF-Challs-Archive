<?php

namespace App\Http\Controllers;

use App\Models\Registration;
use App\Models\Schedule;
use Illuminate\Http\Request;
use PDF;

class RegistrationController extends Controller
{
    public function showRegistrationPage() {
        return view('index', ['schedules' => Schedule::all()->sortBy('time')]);
    }

    public function submitRegistration(Request $request) {
        $name = $request->input('name');
        $email = $request->input('email');
        $dob = $request->input('dob');
        $examdate = $request->input('examdate');
        $schedule = Schedule::where('time', $examdate)->first();

        if (!preg_match("/^([a-zA-Z' ]+)$/", $name)
            || !filter_var($email, FILTER_VALIDATE_EMAIL)
            || !preg_match("/^(0?[1-9]|[12][0-9]|3[01])[\/\-](0?[1-9]|1[012])[\/\-]\d{4}$/", $dob)
            || $schedule === null) {
            return redirect('/')->with('error', 'Invalid registration data.');
        }

        $registration = new Registration;
        $registration->name = $name;
        $registration->email = $email;
        $registration->birthdate = $dob;
        $registration->examdate = $examdate;
        $registration->photo = resource_path('photos') . '/default.png';
        $registration->save();

        if ($request->file('photo') !== null) {
            $allowed_extensions = array('jpg', 'jpeg', 'bmp', 'png', 'gif');
            $ext = $request->file('photo')->getClientOriginalExtension();
            if (in_array($ext, $allowed_extensions)) {
                $file_name = $registration->id . '.' . $ext;
                $request->file('photo')->move(resource_path('photos'), $file_name);
                $registration_photo = resource_path('photos') . '/' . $file_name;
                $type = mime_content_type($registration_photo);
                if (strpos($type, 'image') === 0) {
                    $registration->photo = $registration_photo;
                } else {
                    unlink($registration_photo);
                }
            }
        }

        $registration->save(); 

        return redirect('/registered?registrationId=' . $registration->id);
    }

    public function showAfterRegistrationPage(Request $request) {
        $registrationId = $request->query('registrationId');
        $registration = null;
        if (is_string($registrationId) && preg_match('/^[a-f\d]{8}(-[a-f\d]{4}){4}[a-f\d]{8}$/i', $registrationId)) {
            $registration = Registration::where('id', $registrationId)->first();
         }
         if ($registration === null) {
            return redirect('/');
        }
        return view('registered', ['registrationId' => $registrationId]);
    }

    public function downloadExamCard(Request $request) {
        $registrationId = $request->query('registrationId');
        $registration = null;
        if (is_string($registrationId) && preg_match('/^[a-f\d]{8}(-[a-f\d]{4}){4}[a-f\d]{8}$/i', $registrationId)) {
            $registration = Registration::where('id', $registrationId)->first();
         }
         if ($registration === null) {
            return redirect('/');
        }
        $data = [
            'registrationId' => $registrationId,
            'name' => $registration->name,
            'email' => $registration->email,
            'dob' => $registration->birthdate,
            'examdate' => $registration->examdate,
            'photo' => $registration->photo
        ];
        $pdf = PDF::loadView('examcard', $data);
        return $pdf->stream('examcard.pdf');
    }
}
