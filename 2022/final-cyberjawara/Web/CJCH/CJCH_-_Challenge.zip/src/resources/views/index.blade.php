<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>CJCH Exam Registration</title>
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css"
        rel="stylesheet"
        integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6"
        crossorigin="anonymous">
    <style>
        .main {
            margin: 5em auto;
            width: 50%;
        }
        .registration {
            margin: 2em auto;
        }
        .form-group {
            margin: 1em auto;
        }
    </style>
</head>
<body>
<div class="main">
    <h1>Cyber Jawara Certified Hacker Exam - Registration Form</h1>
    @if ($message = Session::get('error'))
    <div class="alert alert-danger alert-block">
        <strong>{{ $message }}</strong>
    </div>
    @endif
    <form class="registration" method="POST" action="/" enctype="multipart/form-data">
        @csrf
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" class="form-control" name="name" placeholder="Full name">
        </div>
        <div class="form-group">
            <label for="email">Email address</label>
            <input type="email" class="form-control" name="email" aria-describedby="emailHelp" placeholder="Enter email">
        </div>
        <div class="form-group">
            <label for="birthdate">Birthdate</label>
            <input type="text" class="form-control" name="dob" placeholder="DD/MM/YYYY">
        </div>
        <div class="form-group">
            <label for="examdate">Exam Date</label>
            <p>
                <select class="exam-select" name="examdate">
                    <option selected>Select available date</option>
                    @foreach ($schedules as $schedule)
                        <option value="{{ $schedule->time }}">{{ $schedule->time }}</option>
                    @endforeach
                </select>
            </p>
        </div>
        <div class="form-group">
            <label for="photo">Upload your photo</label>
            <input type="file" class="form-control" name="photo">
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-primary">Register</button>
        </div>
    </form>
</div>
<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf"
    crossorigin="anonymous">
</script>
</body>
</html>