<html>
  <head>
    <title>CJCH Exam Card - {{ $registrationId }}</title>
    <style>
        .card {
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
        max-width: 300px;
        margin: auto;
        text-align: center;
        }

        .card img {
        max-height: 300px;
        width: 100%;
        }

        .email {
        color: grey;
        font-size: 18px;
        }

        span {
        border: none;
        outline: 0;
        display: inline-block;
        color: white;
        background-color: #000;
        text-align: center;
        width: 100%;
        font-size: 14px;
        }
    </style>
  </head>
  <body>
    <div class="card">
        <img src="{{ $photo }}">
        <h1>{{ $name }}</h1>
        <p class="email">{{ $email }}</p>
        <p>DOB: {{ $dob }}</p>
        <p>Exam Time: {{ $examdate }}</p>
        <p><span>ID: {{ $registrationId }}</span></p>
    </div>
  </body>
</html>

