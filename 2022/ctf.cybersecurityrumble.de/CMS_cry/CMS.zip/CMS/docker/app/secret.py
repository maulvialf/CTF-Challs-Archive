import os

flag = os.environ['FLAG']
key_p, key_q, key_e, key_d = (1,1,1,1)
key_n = key_p * key_q
