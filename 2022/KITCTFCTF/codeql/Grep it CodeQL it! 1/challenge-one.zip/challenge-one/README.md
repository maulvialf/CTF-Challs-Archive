# Getting Started
1. Follow the instructions from https://github.com/github/vscode-codeql-starter#instructions to install CodeQL starter workspace
1. **Make sure that you included the submodules of `vscode-codeql-starter`!**
1. Import the challenge database into VS Code (https://codeql.github.com/docs/codeql-for-visual-studio-code/analyzing-your-projects/)
1. Create a CodeQL query (in the `codeql-custom-queries-ruby` directory of the `vscode-codeql-starter` workspace) that finds exactly what the challenge description on CTFd says

# Support Material
- https://codeql.github.com/docs/codeql-for-visual-studio-code/exploring-the-structure-of-your-source-code/
- The _hint spoiler sections_ scattered throughout the document that is available at https://github.com/githubuniverseworkshops/codeql/tree/main/workshop-2022#section-1-reasoning-about-syntactic-information might help you when writing a query. (This workshop and the hints are NOT related to this challenge in any way, but may be helpful nonetheless)
- https://codeql.github.com/docs/codeql-language-guides/codeql-for-ruby/
- https://codeql.github.com/codeql-standard-libraries/ruby/
- If you're stuck, try extracting parts of your query into smaller parts and test whether the individual parts make sense. To test the individual parts, use the "CodeQL: Quick Evaluation" command as described here: https://codeql.github.com/docs/codeql-for-visual-studio-code/analyzing-your-projects/#running-a-specific-part-of-a-query-or-library