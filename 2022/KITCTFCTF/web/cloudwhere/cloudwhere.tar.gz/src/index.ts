import { init, start } from "./server";

await init()
await start()
