#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>

#include <seccomp.h>
#include <unistd.h>


#define ADD_SECCOMP_RULE(ctx, ...)                      \
  do {                                                  \
    if(seccomp_rule_add(ctx, __VA_ARGS__) < 0) {        \
      perror("Could not add seccomp rule. This is not your fault. The challenge is broken.");             \
      seccomp_release(ctx);                             \
      exit(-1);                                         \
    }                                                   \
  } while(0)


#define ALARM_SECONDS 10

void be_a_ctf_challenge() {
    alarm(ALARM_SECONDS);
}

int main() {
    be_a_ctf_challenge();
    puts("Okay, since you are in here, you can take a look at it. But no photos!");
    setvbuf(stdout,(char *)0x0,2,1);
    char buffer[100];
    int fd = open("./flag.txt", O_RDONLY);
    if (fd < 0) {
        perror("Could not open flag file");
        exit(-1);
    }
    printf("The kœri is safely(?) stored in fd %d\n", fd);
    scmp_filter_ctx ctx;
    ctx = seccomp_init(SCMP_ACT_KILL);
    ADD_SECCOMP_RULE(ctx, SCMP_ACT_ALLOW, SCMP_SYS(read      ), 0);
    if(seccomp_load(ctx) < 0) {
        perror("Could not load seccomp context! This is not your fault. The challenge is broken.");
        exit(-1);
    }
    read(0, buffer, 0x1000);
}
