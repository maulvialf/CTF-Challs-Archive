<?php
    $flag="<<REDACTED>>";
?>