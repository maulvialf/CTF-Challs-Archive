<?php
    $secret="<<REDACTED>>";
?>