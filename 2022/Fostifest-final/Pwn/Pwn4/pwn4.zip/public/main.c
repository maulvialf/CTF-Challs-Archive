#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#define NUM_ARTIST 10
#define NUM_ALBUM 30

typedef struct s_album Album;
typedef struct s_artist Artist;

typedef struct s_album {
	char* album_name;
	Album* next;
	Album* prev;
	Artist* artist;
	unsigned int num_song;
	char* songs[];
} Album;

typedef struct s_artist {
	Album* head;
	Album* tail;
	unsigned int num_album;
	char artist_name[];
} Artist;

Artist* artists[NUM_ARTIST];
Album* albums[NUM_ALBUM];

static inline int readline(char* buf, int len) {
	int n;
	n = read(0, buf, len);
	if(n < 0) {
		printf("Read error\n");
		exit(1);
	}
	if(n > 0 && buf[n-1] == '\n') {
		buf[n-1] = '\0';
	}
	return n;
}

unsigned int readint() {
	char buf[25];
	int res;
	readline(buf, 25);
	res = strtol(buf, NULL, 10);
	return res;
}

void add_artist(void) {
	unsigned int i;
	unsigned int idx = -1;
	char artist_name[0x400];
	for(i = 0; i < NUM_ARTIST; i++) {
		if(artists[i] == NULL) {
			idx = i;
			break;
		}
	}
	if(idx == -1) {
		printf("Artist full!\n");
		return;
	}
	printf("Enter artist name: ");
	unsigned int len_name = readline(artist_name, 0x400);
	if(!(artists[idx] = malloc(sizeof(Artist) + len_name))) {
		printf("Malloc error\n");
		exit(1);
	}
	memset(artists[idx], 0, sizeof(Artist));
	strncpy(artists[idx]->artist_name, artist_name, len_name);
	printf("Artist created at %d\n", idx);
}

void view_artists(void) {
	unsigned int i;
	unsigned int idx;
	Album* album;
	for(i = 0; i < NUM_ARTIST; i++) {
		if(artists[i] == NULL) continue;
		printf("Artists #%d", i);
		printf(" : %s - has %d albums\n", artists[i]->artist_name,
			artists[i]->num_album);
	}
	printf("Select artist to view albums: ");
	idx = readint();
	if(idx >= NUM_ARTIST || artists[idx] == NULL) {
		printf("Invalid artist\n");
		return;
	}
	for(album = artists[idx]->head; album != NULL; album = album->next) {
		printf("- %s has %d songs\n", album->album_name, album->num_song);
	}
}

void del_artists(void) {
	unsigned int idx;
	printf("Enter artist index: ");
	idx = readint();
	if(idx >= NUM_ARTIST || artists[idx] == NULL) {
		printf("Invalid artist\n");
		return;
	}
	free(artists[idx]);
	artists[idx] = NULL;
	printf("Done\n");
	return;
}

void add_album(void) {
	unsigned int artist_idx;
	unsigned int idx = -1;
	unsigned int i;
	char song_name[0x100];
	char* album_name;
	unsigned int num_song = 0;
	unsigned int album_name_length;
	Artist* artist;
	Album* tmp;
	for(i = 0; i < NUM_ALBUM; i++) {
		if(albums[i] == NULL) {
			idx = i;
			break;
		}
	}
	if(idx == -1) {
		printf("Album full!\n");
		return;
	}
	printf("Artist index: ");
	artist_idx = readint();
	if(artist_idx >= NUM_ARTIST && artists[artist_idx] == NULL) {
		printf("Invalid artist\n");
		return;
	}
	artist = artists[artist_idx];

	printf("Album name length: ");
	album_name_length = readint();
	if(album_name_length >= 0x400) {
		printf("Too big!\n");
		return;
	}

	album_name = malloc(album_name_length);
	if(!album_name) {
		printf("Malloc error!\n");
		exit(1);
	}

	printf("Album name: ");
	readline(album_name, album_name_length);
	printf("How many songs: ");
	num_song = readint();
	albums[idx] = malloc(sizeof(Album)+sizeof(char*)*num_song);
	albums[idx]->album_name = album_name;
	albums[idx]->artist = artist;

	// Insert new tail
	tmp = artist->tail;
	if(tmp) {
		tmp->next = albums[idx];
		albums[idx]->next = NULL;
	} else {
		artist->head = albums[idx];
	}
	albums[idx]->prev = tmp;
	artist->tail = albums[idx];

	albums[idx]->num_song = num_song;
	memset(song_name, 0, 0x100);
	for(i = 0; i < num_song; i++) {
		printf("Enter #%d song: ", i);
		readline(song_name, 0x100);
		song_name[0x100-1] = '\0';
		albums[idx]->songs[i] = strdup(song_name);
	}

	artist->num_album++;
	printf("Album created at %d\n", idx);
}

void view_album(void) {
	unsigned int i;
	unsigned int idx;
	Album* album;
	printf("Enter Album Index: ");
	idx = readint();
	if(idx >= NUM_ALBUM && albums[idx] == NULL) {
		printf("Invalid album\n");
		return;
	}
	album = albums[idx];
	printf("Album %s\n", album->album_name);
	printf("by %s\n", album->artist->artist_name);
	printf("Songs list: \n");
	for(i = 0; i < album->num_song; i++) {
		printf("#%d : %s\n", i, album->songs[i]);
	}
}

void del_album(void) {
	unsigned int i;
	unsigned int idx;
	Album* album;
	printf("Enter Album Index: ");
	idx = readint();
	if(idx >= NUM_ALBUM && albums[idx] == NULL) {
		printf("Invalid album\n");
		return;
	}
	album = albums[idx];
	if(album->next) {
		album->next->prev = album->prev;
	} else {
		album->artist->tail = album->prev;
	}

	if(album->prev) {
		album->prev->next = album->next;
	} else {
		album->artist->head = album->next;
	}

	album->artist->num_album--;
	free(album->album_name);
	free(album);
	albums[idx] = NULL;
}

void timeout(int n) {
	printf("Timeout!\n");
	exit(1);
}

int init_prog(void) {
	setvbuf(stdin,(char *)0x0,2,0);
	setvbuf(stdout,(char *)0x0,2,0);
	setvbuf(stderr,(char *)0x0,2,0);
	alarm(60);
	signal(SIGALRM, timeout);
}

void menu() {
	printf("====== MENU ======\n");
	printf("[1] Add Artist\n");
	printf("[2] View Artist\n");
	printf("[3] Delete Artist\n");
	printf("[4] Add Album\n");
	printf("[5] View Album\n");
	printf("[6] Delete Album\n");
	printf("[7] Exit\n");
	printf("> ");
}


int main(int argc, char** argv)
{
	init_prog();
	int c;
	while(1) {
		menu();
		c = readint();
		switch(c) {
			case 1:
				add_artist();
				break;
			case 2:
				view_artists();
				break;
			case 3:
				del_artists();
				break;
			case 4:
				add_album();
				break;
			case 5:
				view_album();
				break;
			case 6:
				del_album();
				break;
			case 7:
				printf("Bye!\n");
				return 0;
			default:
				printf("Wrong choice\n");
				break;
		}
	}
}
