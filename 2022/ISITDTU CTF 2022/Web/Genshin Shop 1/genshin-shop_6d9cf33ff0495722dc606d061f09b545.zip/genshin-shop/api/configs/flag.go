package configs

type Flag struct {
	GenshinShop1 string `yaml:"genshin_shop_1"`
	GenshinShop2 string `yaml:"genshin_shop_2"`
}
