<script setup lang="ts">
</script>

<template>
    <nav class="navbar navbar-expand-lg bg-dark navbar-light d-none d-lg-block" id="templatemo_nav_top">
        <div class="container text-light">
            <div class="w-100 d-flex justify-content-between">
                <div>
                    <i class="fa fa-envelope mx-2"></i>
                    <a class="navbar-sm-brand text-light text-decoration-none"
                        href="mailto:shop@genshin-shop.net">shop@genshin-shop.net</a>
                    <i class="fa fa-phone mx-2"></i>
                    <a class="navbar-sm-brand text-light text-decoration-none" href="tel:0999999999">099.999.9999</a>
                </div>
                <div>
                    <a class="text-light" href="https://www.facebook.com/" target="_blank" rel="sponsored">
                        <font-awesome-icon icon="fa-brands fa-facebook-f" class="fa-sm fa-fw me-2"></font-awesome-icon>
                    </a>
                    <a class="text-light" href="https://www.instagram.com/" target="_blank">
                        <font-awesome-icon icon="fa-brands fa-instagram" class="fa-sm fa-fw me-2"></font-awesome-icon>
                    </a>
                    <a class="text-light" href="https://twitter.com/" target="_blank">
                        <font-awesome-icon icon="fa-brands fa-twitter" class="fa-sm fa-fw me-2"></font-awesome-icon>
                    </a>
                    <a class="text-light" href="https://www.linkedin.com/" target="_blank">
                        <font-awesome-icon icon="fa-brands fa-linkedin" class="fa-sm fa-fw me-2"></font-awesome-icon>
                    </a>
                </div>
            </div>
        </div>
    </nav>
</template>