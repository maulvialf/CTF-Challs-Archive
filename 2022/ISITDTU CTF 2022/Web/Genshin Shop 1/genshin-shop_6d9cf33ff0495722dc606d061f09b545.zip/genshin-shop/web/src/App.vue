<script setup lang="ts">
import Banner from './components/Banner.vue'
import Tier from './components/Tier.vue'
import Product from './components/Product.vue'
import Footer from './components/Footer.vue'
import Header from './components/Header.vue'
import Nav from './components/Nav.vue'
</script>

<template>
	<Header></Header>
	<Nav></Nav>
	<Banner></Banner>
	<Tier></Tier>
	<Product></Product>
	<Footer></Footer>
</template>