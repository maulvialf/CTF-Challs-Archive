FLAG = b"CSR{lololololololololololol}"
