# ALLES!Chat
Running `docker-compose up` will expose the api on port 1024 and start the support bot which will then login to said api.
You can start ALLES!Chat for yourself by going in the `./app` folder, installing the dependencies with `npm install` and then running `npm start`. When signing up / logging in, you can specify the api url (for local testing use: `http://127.0.0.1:1024`, for remote the broker url).
We recommend getting used to the app and debugging your exploit locally with docker first and afterwards trying it on remote.

Screw discord and enjoy your absolutely safe next-gen messaging experience with ALLES!Chat :^)