import setuptools


setuptools.setup(
     name='blackStab',  
     version='13.37',
     packages=['blackStab'],
     author="Jaswanth Bommidi",
     author_email="mail@evilsyn.com",
     description="blackStab Cloud Services",
     classifiers=[
         "Programming Language :: Python :: 3",
         "License :: OSI Approved :: MIT License",
         "Operating System :: OS Independent",
     ],
 )
