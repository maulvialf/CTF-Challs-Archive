```bash
pip install .
```