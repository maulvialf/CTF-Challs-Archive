#![allow(warnings, unused)]
fn main() {
    println!("Hello, world!");
}
