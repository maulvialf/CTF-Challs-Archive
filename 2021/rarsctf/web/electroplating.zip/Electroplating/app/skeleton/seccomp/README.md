seccomp
-------

This library provides a higher-level wrapper around [libseccomp](https://github.com/seccomp/libseccomp).

Add to Cargo.toml:

```
[dependencies]
seccomp = "0.1"
```

[Documentation](http://plhk.ru/static/doc/seccomp/seccomp/index.html)
