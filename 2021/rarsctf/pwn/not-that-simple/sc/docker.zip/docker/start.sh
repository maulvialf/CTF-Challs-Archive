#!/bin/sh
cd /pwn
./notsimple

