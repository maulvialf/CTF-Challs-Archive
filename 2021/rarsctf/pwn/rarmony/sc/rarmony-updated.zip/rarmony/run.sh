#!/bin/bash

cd /harmony/
./harmony
