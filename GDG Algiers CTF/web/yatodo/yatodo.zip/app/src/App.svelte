<script>
  import Home from "./lib/Home.svelte";
</script>

<main>
    <Home />
</main>

<style>
</style>
